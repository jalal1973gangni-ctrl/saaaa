"""
Telegram bot handlers — full premium redesign.
• Owner-granted access control (/hgnice, /rm, /access)
• Per-user sessions — every member logs in with their OWN HGNICE account
• New fonts via Unicode styled text
• Premium animations: multi-frame loading + 4-second prediction animation
• BALANCE & STATISTICS buttons/handlers removed
• Full flow: welcome → login → target → steps → trade → result → logout
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional

from telegram import Update, Message, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from bot.keyboards import (
    login_keyboard,
    home_keyboard,
    about_keyboard,
    main_menu_keyboard,
    back_to_login_keyboard,
    confirm_keyboard,
    start_cancel_keyboard,
)
from bot.states import BotState
from config.settings import settings
from core.period_manager import period_manager
from core.risk_manager import risk_manager
from core.session import UserSession, get_session, session_for
from services.hgnice_api import HGNiceAPIError
from storage.database import db

logger = logging.getLogger(__name__)

# ════════════════════════════════════════════════════════════════════════════
#   DESIGN CONSTANTS
# ════════════════════════════════════════════════════════════════════════════

BANNER  = "━━━━━━━━━━━━━━━━━━━━━━━━━━"
BANNER2 = "▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱"

# Unicode styled headers (mathematical bold / sans-serif bold)
TXT_BOT     = "𝗛𝗚𝗡𝗜𝗖𝗘 𝗔𝗨𝗧𝗢 𝗧𝗥𝗔𝗗𝗘 𝗕𝗢𝗧"
TXT_SYSTEM  = "𝗔𝗨𝗧𝗢 𝗧𝗥𝗔𝗗𝗘 𝗦𝗬𝗦𝗧𝗘𝗠"
TXT_LOGIN   = "𝗔𝗖𝗖𝗢𝗨𝗡𝗧 𝗟𝗢𝗚𝗜𝗡"
TXT_TARGET  = "𝗦𝗧𝗔𝗥𝗧 𝗬𝗢𝗨𝗥 𝗧𝗔𝗥𝗚𝗘𝗧"
TXT_CONFIG  = "𝗧𝗥𝗔𝗗𝗘 𝗖𝗢𝗡𝗙𝗜𝗚𝗨𝗥𝗔𝗧𝗜𝗢𝗡"
TXT_TRADE   = "𝗔𝗨𝗧𝗢 𝗧𝗥𝗔𝗗𝗘 𝗔𝗖𝗧𝗜𝗩𝗘"

# Loading animation frames
SPIN_FRAMES  = ["⠋", "⠙", "⠸", "⠼", "⠴", "⠦"]
DOT_FRAMES   = ["⏳", "⠿", "⠿⠿", "⠿⠿⠿", "✅"]


# ════════════════════════════════════════════════════════════════════════════
#   HELPERS
# ════════════════════════════════════════════════════════════════════════════

def _current_period() -> str:
    return period_manager.calculate_period(datetime.now(timezone.utc))

def _timer() -> int:
    now = datetime.now(timezone.utc)
    return 30 - (now.second % 30)

def _timer_bar(seconds: int) -> str:
    filled = min(10, max(0, round(seconds / 3)))
    return "█" * filled + "░" * (10 - filled)


def _money(value) -> str:
    """Format a wallet value safely — None/unknown → '—'."""
    if isinstance(value, (int, float)):
        return f"৳ {value:.2f}"
    return "—"


def _uid(update: Update) -> int:
    """Telegram user id behind this update (0 when unavailable)."""
    user = update.effective_user
    return user.id if user else 0


def _sess(uid: int) -> UserSession:
    """The isolated session (state / api / trade loop) owned by ``uid``."""
    return get_session(uid)


def _is_owner(update: Update) -> bool:
    user = update.effective_user
    return bool(user) and user.id == settings.OWNER_ID


async def _user_allowed(uid: int) -> bool:
    """Owner always passes; everyone else needs an explicit grant."""
    if uid == settings.OWNER_ID:
        return True
    if uid <= 0:
        return False
    try:
        return await db.has_access(uid)
    except Exception as exc:
        logger.error("Access check failed for %s: %s", uid, exc)
        return False


def authorized_only(func):
    """Decorator: only the owner and users he granted access to may run."""
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        uid = _uid(update)
        if not await _user_allowed(uid):
            if update.message:
                await update.message.reply_text(
                    f"{BANNER}\n"
                    f"⛔ *ACCESS REQUIRED*\n"
                    f"{BANNER}\n\n"
                    f"🔒 This bot is *private*.\n"
                    f"The owner must add you first with `/hgnice`.\n\n"
                    f"👤 *Your Telegram ID*\n"
                    f"   `{uid}`\n\n"
                    f"_Send this ID to the bot owner to get access._",
                    parse_mode=ParseMode.MARKDOWN,
                )
            elif update.callback_query:
                await update.callback_query.answer(
                    "⛔ ACCESS DENIED — Ask the owner for access", show_alert=True
                )
            return
        return await func(update, ctx)
    wrapper.__name__ = func.__name__
    return wrapper


async def _reply(update: Update, text: str, **kwargs) -> Optional[Message]:
    """Safe reply — works for both messages and callback queries."""
    kwargs.setdefault("parse_mode", ParseMode.MARKDOWN)
    msg = update.message or (
        update.callback_query.message if update.callback_query else None
    )
    if msg:
        return await msg.reply_text(text, **kwargs)
    return None


async def _edit_or_reply(query, text: str, **kwargs) -> None:
    """Edit existing message, fall back to reply."""
    try:
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, **kwargs)
    except Exception:
        await query.message.reply_text(text, parse_mode=ParseMode.MARKDOWN, **kwargs)


async def _edit_text(msg: Message, text: str) -> None:
    """Edit a message, retrying without Markdown if Telegram cannot parse it."""
    try:
        await msg.edit_text(text, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        try:
            await msg.edit_text(text)
        except Exception:
            pass


async def _send_to(ctx, chat_id: int, text: str) -> Optional[Message]:
    """Send a message, retrying without Markdown if Telegram cannot parse it."""
    try:
        return await ctx.bot.send_message(chat_id, text, parse_mode=ParseMode.MARKDOWN)
    except Exception:
        try:
            return await ctx.bot.send_message(chat_id, text)
        except Exception as exc:
            logger.error("send_message to %s failed: %s", chat_id, exc)
            return None


async def _progress_loading(
    message: Message,
    base: str,
    steps: int = 5,
    delay: float = 0.45,
    final_text: Optional[str] = None,
) -> Message:
    """Multi-frame progress-bar animation. Returns the message."""
    msg = await message.reply_text(
        f"{base}\n`[░░░░░░░░░░] 0%`", parse_mode=ParseMode.MARKDOWN
    )
    for i in range(1, steps + 1):
        await asyncio.sleep(delay)
        pct = round(i / steps * 100)
        filled = round(i / steps * 10)
        bar = "█" * filled + "░" * (10 - filled)
        try:
            await msg.edit_text(
                f"{base}\n`[{bar}] {pct}%`", parse_mode=ParseMode.MARKDOWN
            )
        except Exception:
            pass
    if final_text:
        await _edit_text(msg, final_text)
    return msg


# ════════════════════════════════════════════════════════════════════════════
#   /start  — Welcome Screen
# ════════════════════════════════════════════════════════════════════════════

@authorized_only
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    sess = _sess(_uid(update))
    if update.effective_chat:
        sess.chat_id = update.effective_chat.id
    state_manager = sess.state
    state = state_manager.get_state()

    if state == BotState.TRADING:
        await _reply(
            update,
            f"{BANNER}\n"
            f"⚠️ *AUTO TRADE IS RUNNING*\n"
            f"{BANNER}\n\n"
            f"A trading session is currently active.\n"
            f"Use *🛑 STOP TRADE* to stop it first.",
            reply_markup=main_menu_keyboard(),
        )
        return

    if state not in (BotState.LOGGED_IN, BotState.READY):
        await state_manager.set_state(BotState.NOT_LOGGED_IN)

    await _send_home(update.message)


ABOUT_TEXT = (
    "👨‍💻 *Developer Info*\n\n"
    "👤 *Name:* MD.SHAHRIAR SAIF\n"
    "📱 *Telegram:* @TRADER\\_SAIF\n\n"
    "🤖 This bot was created and developed\n"
    "by *MD.SHAHRIAR SAIF*\n\n"
    "📩 যেকোনো সমস্যা বা feature request-এর জন্য\n"
    "Telegram-এ contact করো।"
)


async def _send_home(message: Message) -> None:
    await message.reply_text(
        f"╔══════════════════════════╗\n"
        f"║  🤖  {TXT_BOT}  🤖  ║\n"
        f"╚══════════════════════════╝\n\n"
        f"👇 একটি অপশন বেছে নাও",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=home_keyboard(),
    )


async def _send_welcome(message: Message, user=None, platform: str = "hgnice") -> None:
    is_owner = bool(user) and user.id == settings.OWNER_ID
    try:
        members = await db.count_access()
    except Exception:
        members = 0

    access_line = (
        f"👑 *Access*    :  Owner Console · `{members}` member(s) added"
        if is_owner
        else "🔒 *Access*    :  Private · Authorized Members"
    )

    text = (
        f"╔══════════════════════════╗\n"
        f"║  🤖  {TXT_BOT}  🤖  ║\n"
        f"╚══════════════════════════╝\n\n"
        f"   ✦ ✦ ✦  *{TXT_SYSTEM}*  ✦ ✦ ✦\n\n"
        f"{BANNER}\n"
        f"🌐 *Platform*  :  {platform.upper()} WinGo 30S\n"
        f"⚡ *Mode*      :  Auto Analyse & Bet\n"
        f"{access_line}\n"
        f"🔴 *Status*    :  Not Logged In\n"
        f"{BANNER}\n\n"
        f"🧠 *Smart Pattern Engine — Last 10*\n"
        f"   〰️ Zigzag · 🔴 Big trend · 🔵 Small trend\n"
        f"   📈 Tan follow · 🐉 Dragon · ✌️ 2-2 · 🔱 3-3\n"
        f"   🔁 2-1 / 1-2 · 🪞 Mirror · 🔀 Markov\n"
        f"   🪤 Dragon trap & Zigzag trap detection\n"
        f"   🛡 Rules ranked by live *2-level* win-rate\n"
        f"   🛑 Confidence below `{settings.MIN_CONFIDENCE}%` → sit out\n\n"
        f"{BANNER}\n"
        f"🎬 *4-second* 🧠 _generating prediction_ animation\n"
        f"🚀 Analysis → auto bet every 30s period\n\n"
        f"{BANNER}\n"
        f"👇 Press the button below to *LOGIN*"
    )
    await message.reply_text(
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=login_keyboard(platform)
    )


# ════════════════════════════════════════════════════════════════════════════
#   ACCESS CONTROL — only the owner may add / remove members
# ════════════════════════════════════════════════════════════════════════════

async def _require_owner(update: Update) -> bool:
    if _is_owner(update):
        return True
    await _reply(
        update,
        f"{BANNER}\n"
        f"👑 *OWNER ONLY*\n"
        f"{BANNER}\n\n"
        f"Only the bot owner can manage member access."
    )
    return False


def _parse_target(args) -> Optional[int]:
    """Pull a Telegram user id out of a command argument list."""
    if not args:
        return None
    raw = str(args[0]).strip().lstrip("@")
    return int(raw) if raw.isdigit() else None


_ACCESS_USAGE = (
    f"{BANNER}\n"
    f"🔑 *ACCESS COMMANDS*\n"
    f"{BANNER}\n\n"
    f"➕ *Grant*   : `/hgnice <telegram_user_id>`\n"
    f"➖ *Revoke*  : `/rm <telegram_user_id>`\n"
    f"📋 *List*    : `/access`\n"
    f"🆔 *My ID*   : `/id`\n"
    f"ℹ️ *Help*    : `/help`\n\n"
    f"_Send `/id` to anyone who wants in, then grant it here._"
)


async def cmd_grant_access(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """/hgnice <tguserid> — owner grants a member access."""
    if not await _require_owner(update):
        return
    target = _parse_target(ctx.args)
    if target is None:
        await _reply(update, f"❌ *Invalid or missing id.*\n\n{_ACCESS_USAGE}")
        return
    if target == settings.OWNER_ID:
        await _reply(update, "ℹ️ That is the owner — access is always on.")
        return

    try:
        await db.add_access(target, settings.OWNER_ID)
    except Exception as exc:
        logger.error("Grant access failed: %s", exc)
        await _reply(update, f"❌ Could not save access:\n`{exc}`")
        return

    try:
        members = await db.count_access()
    except Exception:
        members = 0

    # Welcome message — works only if that user already opened the bot.
    try:
        await ctx.bot.send_message(
            target,
            f"{BANNER}\n"
            f"🎉 *ACCESS GRANTED*\n"
            f"{BANNER}\n\n"
            f"The owner just gave you access to *{TXT_SYSTEM}*.\n\n"
            f"1️⃣ Press /start\n"
            f"2️⃣ Login with *your own* HGNICE account\n"
            f"3️⃣ Set your target and start trading\n\n"
            f"{BANNER}\n"
            f"🔒 Your session is *private* — nobody else can see it.",
            parse_mode=ParseMode.MARKDOWN,
        )
        notified = True
    except Exception:
        notified = False

    await _reply(
        update,
        f"{BANNER}\n"
        f"✅ *ACCESS GRANTED*\n"
        f"{BANNER}\n\n"
        f"👤 *User ID* : `{target}`\n"
        f"👥 *Members* : `{members}`\n"
        f"📨 *Notified* : `{'yes' if notified else 'not yet (user never started the bot)'}`\n\n"
        f"They can now /start, login with their own account and trade."
    )


async def cmd_remove_access(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """/rm <tguserid> — owner revokes a member's access."""
    if not await _require_owner(update):
        return
    target = _parse_target(ctx.args)
    if target is None:
        await _reply(update, f"❌ *Invalid or missing id.*\n\n{_ACCESS_USAGE}")
        return
    if target == settings.OWNER_ID:
        await _reply(update, "🚫 The owner's access cannot be removed.")
        return

    try:
        removed = await db.remove_access(target)
    except Exception as exc:
        logger.error("Remove access failed: %s", exc)
        await _reply(update, f"❌ Could not update access:\n`{exc}`")
        return

    if not removed:
        await _reply(
            update,
            f"ℹ️ `{target}` was *not* on the access list.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # Kick them out of a live session so they cannot keep trading.
    sess = session_for(target)
    if sess is not None:
        try:
            await sess.trade.stop("Access revoked")
        except Exception as exc:
            logger.warning("Stopping revoked user's loop failed: %s", exc)

    try:
        await ctx.bot.send_message(
            target,
            f"{BANNER}\n"
            f"⛔ *ACCESS REVOKED*\n"
            f"{BANNER}\n\n"
            f"The owner removed your access to this bot.\n"
            f"Contact the owner if this was a mistake.",
            parse_mode=ParseMode.MARKDOWN,
        )
    except Exception:
        pass

    await _reply(
        update,
        f"{BANNER}\n"
        f"🗑️ *ACCESS REMOVED*\n"
        f"{BANNER}\n\n"
        f"👤 *User ID* : `{target}`\n"
        f"_Their session was stopped._"
    )


async def cmd_list_access(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """/access — show the current membership list (owner only)."""
    if not await _require_owner(update):
        return
    try:
        ids = await db.list_access()
    except Exception as exc:
        await _reply(update, f"❌ Could not read access list:\n`{exc}`")
        return

    if not ids:
        body = "_No members yet. Add one with_ `/hgnice <id>`"
    else:
        body = "\n".join(
            f"   `{i:02d}.`  `{uid}`"
            for i, uid in enumerate(ids, 1)
        )

    await _reply(
        update,
        f"{BANNER}\n"
        f"📋 *ACCESS LIST*\n"
        f"{BANNER}\n\n"
        f"👑 Owner : `{settings.OWNER_ID}`\n"
        f"👥 Members ({len(ids)}):\n"
        f"{body}\n\n"
        f"{_ACCESS_USAGE}"
    )


async def cmd_my_id(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """/id — anyone can fetch their own Telegram id."""
    uid = _uid(update)
    is_owner = uid == settings.OWNER_ID
    try:
        allowed = is_owner or await db.has_access(uid)
    except Exception:
        allowed = is_owner

    await _reply(
        update,
        f"{BANNER}\n"
        f"🆔 *YOUR TELEGRAM ID*\n"
        f"{BANNER}\n\n"
        f"👤 `{uid}`\n"
        f"🔐 *Status* : "
        f"{'👑 owner' if is_owner else ('✅ granted' if allowed else '⛔ not granted')}\n\n"
        f"_Send this ID to the bot owner to get access._"
    )


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """/help — command reference."""
    await _reply(
        update,
        f"{BANNER}\n"
        f"ℹ️ *HELP*\n"
        f"{BANNER}\n\n"
        f"/start — open the bot\n"
        f"/id — show your Telegram id\n"
        f"/help — this message\n\n"
        f"*Owner only:*\n"
        f"/hgnice <id> — grant access\n"
        f"/rm <id> — revoke access\n"
        f"/access — list members\n\n"
        f"*Flow:*\n"
        f"LOGIN → 🚀 START YOUR TARGET → target → steps → START TRADE"
    )


# ════════════════════════════════════════════════════════════════════════════
#   CALLBACK ROUTER
# ════════════════════════════════════════════════════════════════════════════

@authorized_only
async def callback_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    data = query.data or ""
    uid = _uid(update)
    sess = _sess(uid)
    if update.effective_chat:
        sess.chat_id = update.effective_chat.id

    if data == "action:hgnice":
        sess.api.select_platform("hgnice")
        await _send_welcome(query.message, update.effective_user, "hgnice")

    elif data == "action:dkwin":
        sess.api.select_platform("dkwin")
        await _send_welcome(query.message, update.effective_user, "dkwin")

    elif data == "action:about":
        await query.message.reply_text(
            ABOUT_TEXT, parse_mode=ParseMode.MARKDOWN, reply_markup=about_keyboard()
        )

    elif data == "action:home":
        await _send_home(query.message)

    elif data == "action:login" or data == "action:login:hgnice":
        sess.api.select_platform("hgnice")
        await _start_login_flow(query.message, uid)

    elif data == "action:login:dkwin":
        sess.api.select_platform("dkwin")
        await _start_login_flow(query.message, uid)

    elif data == "action:start_trade":
        await _execute_start_trade(query, ctx, uid)

    elif data == "action:cancel_trade":
        await _execute_cancel_trade(query, uid)

    elif data.startswith("confirm:stop:yes"):
        await _execute_stop_trade(query.message, uid)

    elif data.startswith("confirm:stop:no"):
        await query.message.reply_text(
            "✅ Cancelled. Auto trade *continues*.", parse_mode=ParseMode.MARKDOWN
        )

    elif data.startswith("confirm:logout:yes"):
        await _execute_logout(query.message, uid)

    elif data.startswith("confirm:logout:no"):
        await query.message.reply_text(
            "✅ Cancelled. You are still logged in.", parse_mode=ParseMode.MARKDOWN
        )


# ════════════════════════════════════════════════════════════════════════════
#   LOGIN FLOW
# ════════════════════════════════════════════════════════════════════════════

async def _start_login_flow(message: Message, uid: int) -> None:
    state_manager = _sess(uid).state
    await state_manager.set_state(BotState.LOGIN_NUMBER)
    await message.reply_text(
        f"╔══════════════════════════╗\n"
        f"║   🔐  {TXT_LOGIN}  🔐   ║\n"
        f"╚══════════════════════════╝\n\n"
        f"{BANNER}\n"
        f"📱 Enter your *{_sess(uid).api.platform.upper()} phone number:*\n"
        f"{BANNER}\n"
        f"_Everyone uses their own account — your session is private._",
        parse_mode=ParseMode.MARKDOWN,
    )


@authorized_only
async def handle_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """Route text messages based on current FSM state."""
    uid   = _uid(update)
    sess  = _sess(uid)
    if update.effective_chat:
        sess.chat_id = update.effective_chat.id
    state_manager = sess.state

    text  = (update.message.text or "").strip()
    state = state_manager.get_state()

    # ── Menu buttons ─────────────────────────────────────────────────────
    if text == "🚀 START YOUR TARGET":
        await _handle_target_fill_up(update)
        return
    if text == "🛑 STOP TRADE":
        await _handle_stop_trade(update)
        return
    if text == "🚪 LOGOUT":
        await _handle_logout(update)
        return

    # ── FSM-driven input ─────────────────────────────────────────────────
    if state == BotState.LOGIN_NUMBER:
        await _receive_account_number(update, text)
    elif state == BotState.LOGIN_PASSWORD:
        await _receive_password(update, text)
    elif state == BotState.TARGET_INPUT:
        await _receive_target(update, text)
    elif state == BotState.STEP_COUNT_INPUT:
        await _receive_step_count(update, text)
    elif state == BotState.STEP_AMOUNT_INPUT:
        await _receive_step_amount(update, text, ctx)
    else:
        await _reply(update, "ℹ️ Please use the menu buttons below.")


# ── Step 1: account number ──────────────────────────────────────────────────

async def _receive_account_number(update: Update, text: str) -> None:
    state_manager = _sess(_uid(update)).state
    if not text.isdigit() or len(text) < 6:
        await _reply(
            update,
            "❌ *Invalid number.*\n\n"
            "Please enter your phone number _(digits only)_:"
        )
        return
    state_manager.session.account_number = text
    await state_manager.set_state(BotState.LOGIN_PASSWORD)
    await _reply(
        update,
        f"╔══════════════════════════╗\n"
        f"║   🔐  {TXT_LOGIN}  🔐   ║\n"
        f"╚══════════════════════════╝\n\n"
        f"☎️ *Number* : `{text}`\n\n"
        f"🔑 Now enter your *password:*\n"
        f"_Your message will be deleted immediately for security._",
    )


# ── Step 2: password + API login ────────────────────────────────────────────

async def _receive_password(update: Update, text: str) -> None:
    uid           = _uid(update)
    sess          = _sess(uid)
    state_manager = sess.state
    hgnice_api    = sess.api
    state_manager.session.set_password(text)
    try:
        await update.message.delete()
    except Exception:
        pass

    # Multi-frame animated login
    loading = await _progress_loading(
        update.message,
        f"🔄 *CONNECTING TO {hgnice_api.platform.upper()}*",
        steps=5,
        delay=0.5,
    )

    account  = state_manager.session.account_number
    password = state_manager.session.get_password()

    try:
        info = await hgnice_api.login(account, password)
        state_manager.session.set_password("")
        state_manager.session.account_masked = info.account_masked
        state_manager.session.user_id        = info.user_id
        state_manager.session.nick_name      = info.nick_name
        state_manager.stats.current_balance  = info.balance
        await state_manager.set_state(BotState.LOGGED_IN)

        try:
            await loading.delete()
        except Exception:
            pass

        await update.message.reply_text(
            f"╔══════════════════════════╗\n"
            f"║  🎉  {hgnice_api.platform.upper()} LOGIN SUCCESSFUL ✅  ║\n"
            f"╚══════════════════════════╝\n\n"
            f"{BANNER}\n"
            f"☎️ *Phone Number*\n"
            f"   `{info.account_masked}`\n\n"
            f"👤 *Account UID*\n"
            f"   `{info.user_id or '—'}`\n\n"
            f"💰 *Account Balance*\n"
            f"   `৳ {info.balance:.2f}`\n"
            f"{BANNER}\n\n"
            f"🧠 *Analysis Engine:*  READY\n"
            f"🚀 *AutoTrade System:* READY\n\n"
            f"👇 Press *START YOUR TARGET* to begin",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=main_menu_keyboard(),
        )

    except HGNiceAPIError as exc:
        state_manager.session.set_password("")
        await state_manager.set_state(BotState.NOT_LOGGED_IN)
        try:
            await loading.delete()
        except Exception:
            pass
        await update.message.reply_text(
            f"{BANNER}\n"
            f"❌ *LOGIN FAILED*\n"
            f"{BANNER}\n\n"
            f"🚫 *Reason* : `{exc}`\n\n"
            f"Please check your credentials and try again.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=login_keyboard(hgnice_api.platform),
        )


# ════════════════════════════════════════════════════════════════════════════
#   MENU HANDLERS  (BALANCE & STATISTICS removed)
# ════════════════════════════════════════════════════════════════════════════

async def _handle_stop_trade(update: Update) -> None:
    state_manager = _sess(_uid(update)).state
    if state_manager.get_state() not in (BotState.TRADING, BotState.WAITING_RESULT):
        await _reply(update, "ℹ️ No active trading session to stop.")
        return
    await _reply(
        update,
        f"{BANNER}\n"
        f"🛑 *STOP AUTO TRADE?*\n"
        f"{BANNER}\n\n"
        f"Are you sure you want to stop the current session?",
        reply_markup=confirm_keyboard("stop"),
    )


async def _execute_stop_trade(message: Message, uid: int) -> None:
    sess          = _sess(uid)
    state_manager = sess.state
    hgnice_api    = sess.api
    trade_manager = sess.trade

    loading = await message.reply_text("🛑 *Stopping…*", parse_mode=ParseMode.MARKDOWN)
    await trade_manager.stop("Manual stop")
    try:
        balance = await hgnice_api.get_balance(
            fallback=state_manager.stats.current_balance
        )
        state_manager.stats.current_balance = balance
    except HGNiceAPIError:
        balance = state_manager.stats.current_balance
    await state_manager.set_state(BotState.LOGGED_IN)
    try:
        await loading.delete()
    except Exception:
        pass

    sm = state_manager
    win_rate = (
        f"{sm.stats.total_wins / sm.stats.total_trades * 100:.1f}%"
        if sm.stats.total_trades else "—"
    )
    await message.reply_text(
        f"╔══════════════════════════╗\n"
        f"║  🛑  TRADE STOPPED  🛑   ║\n"
        f"╚══════════════════════════╝\n\n"
        f"💰 *Balance*  : `৳ {balance:.2f}`\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 *Trades*  : {sm.stats.total_trades}\n"
        f"🟢 *Wins*    : {sm.stats.total_wins}\n"
        f"🔴 *Losses*  : {sm.stats.total_losses}\n"
        f"🏆 *Win Rate*: {win_rate}\n"
        f"💹 *Total P/L*: `৳ {sm.stats.total_profit:+.2f}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Session ended manually.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu_keyboard(),
    )


async def _handle_logout(update: Update) -> None:
    await _reply(
        update,
        f"{BANNER}\n"
        f"🚪 *LOGOUT?*\n"
        f"{BANNER}\n\n"
        f"Are you sure you want to logout from HGNICE?",
        reply_markup=confirm_keyboard("logout"),
    )


async def _execute_logout(message: Message, uid: int) -> None:
    sess          = _sess(uid)
    state_manager = sess.state
    hgnice_api    = sess.api
    trade_manager = sess.trade

    loading = await message.reply_text("🔄 *Logging out…*", parse_mode=ParseMode.MARKDOWN)
    if state_manager.get_state() in (BotState.TRADING, BotState.WAITING_RESULT):
        await trade_manager.stop("Logout")
    await state_manager.set_state(BotState.LOGGING_OUT)
    try:
        await hgnice_api.logout()
    except Exception as exc:
        logger.error("Logout error: %s", exc)
    state_manager.reset()
    try:
        await loading.delete()
    except Exception:
        pass
    await message.reply_text(
        f"╔══════════════════════════╗\n"
        f"║  🚪  LOGGED OUT  🚪      ║\n"
        f"╚══════════════════════════╝\n\n"
        f"{BANNER}\n"
        f"✅ You have been *disconnected* from HGNICE.\n\n"
        f"🔐 Press *LOGIN TO ACCOUNT* to connect again.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=back_to_login_keyboard(),
    )


# ════════════════════════════════════════════════════════════════════════════
#   TARGET → STEP FLOW
# ════════════════════════════════════════════════════════════════════════════

async def _handle_target_fill_up(update: Update) -> None:
    uid           = _uid(update)
    sess          = _sess(uid)
    state_manager = sess.state
    hgnice_api    = sess.api

    state = state_manager.get_state()
    if state not in (BotState.LOGGED_IN, BotState.READY):
        await _reply(update, "❌ You must be logged in to start a target.")
        return

    msg = await _reply(
        update, "💰 *SYNCING WALLET…*\n`[░░░░░░░░░░] 0%`"
    )

    # Entering the game = exactly the point where hgnice9.com runs its
    # Transfer call, so the platform wallet is swept into the game wallet
    # BEFORE the balance is read (otherwise GetBalance reports ৳0.00).
    await hgnice_api.transfer_to_game()
    if msg:
        await _edit_text(
            msg, "💰 *TRANSFERRING PLATFORM → GAME…*\n`[████░░░░░░] 40%`"
        )

    cached  = state_manager.stats.current_balance
    warning = ""
    try:
        live = await hgnice_api.get_balance()          # raw, unfallbacked
    except HGNiceAPIError as exc:
        if cached <= 0:
            if msg:
                try:
                    await msg.delete()
                except Exception:
                    pass
            await _reply(update, f"❌ Cannot fetch balance:\n`{exc}`")
            return
        logger.warning("Balance fetch failed — using cached value: %s", exc)
        balance = cached
    else:
        if live <= 0 < cached:
            # Server says the GAME wallet is empty although the platform
            # wallet holds money — show the real figure but warn the user,
            # because bets would be rejected by the server.
            logger.warning(
                "Game wallet reported %.2f while last known balance is %.2f.",
                live, cached,
            )
            balance = cached
            ov = await hgnice_api.get_wallet_overview()
            warning = (
                f"\n⚠️ *Game wallet is EMPTY — bets will fail!*\n"
                f"   Platform wallet : `{_money(ov['platform'])}`\n"
                f"   ARGame wallet   : `{_money(ov['arGame'])}`\n"
                f"   Lottery wallet  : `{_money(ov['lottery'])}`\n"
                f"_Press START YOUR TARGET again, or re-login._\n"
            )
        else:
            balance = live
    state_manager.stats.current_balance = balance
    if msg:
        await _edit_text(msg, "💰 *BALANCE READY*\n`[██████████] 100%`")
        await asyncio.sleep(0.4)
        try:
            await msg.delete()
        except Exception:
            pass

    await state_manager.set_state(BotState.TARGET_INPUT)
    await _reply(
        update,
        f"╔══════════════════════════╗\n"
        f"║  🚀  {TXT_TARGET}  🚀   ║\n"
        f"╚══════════════════════════╝\n\n"
        f"{BANNER}\n"
        f"💰 *YOUR BALANCE*\n"
        f"   `৳ {balance:.2f}`\n"
        f"{BANNER}\n"
        f"{warning}\n"
        f"🎯 *Enter your TARGET profit amount:*\n"
        f"_How much do you want to earn? _(in ৳)__",
    )


async def _receive_target(update: Update, text: str) -> None:
    state_manager = _sess(_uid(update)).state
    try:
        profit = float(text.replace(",", ""))
        if profit <= 0:
            raise ValueError
    except ValueError:
        await _reply(update, "❌ Please enter a valid positive number for target.")
        return

    state_manager.config.target_profit    = profit
    state_manager.config.starting_balance = state_manager.stats.current_balance
    state_manager.config.target_balance   = state_manager.config.starting_balance + profit

    await state_manager.set_state(BotState.STEP_COUNT_INPUT)
    balance = state_manager.stats.current_balance
    await _reply(
        update,
        f"╔══════════════════════════╗\n"
        f"║   🎯  TARGET SET  🎯     ║\n"
        f"╚══════════════════════════╝\n\n"
        f"{BANNER}\n"
        f"💰 *Balance*  : `৳ {balance:.2f}`\n"
        f"🎯 *Target*   : `৳ {profit:.2f}` profit\n"
        f"🏦 *Stop At*  : `৳ {state_manager.config.target_balance:.2f}`\n"
        f"{BANNER}\n\n"
        f"🚀 *Enter your STEP COUNT:*\n"
        f"_How many steps? (e.g. 5, max 50)_",
    )


async def _receive_step_count(update: Update, text: str) -> None:
    state_manager = _sess(_uid(update)).state
    try:
        count = int(text)
        if count < 1 or count > 50:
            raise ValueError
    except ValueError:
        await _reply(update, "❌ Please enter a valid step count _(1–50)_.")
        return

    from core.risk_manager import build_steps
    balance = state_manager.stats.current_balance
    state_manager.config.step_count         = count
    state_manager.config.step_amounts       = build_steps(balance, count)
    state_manager.config.step_base_balance  = balance
    state_manager.config.current_step_input = count + 1

    if not state_manager.config.step_amounts:
        await _reply(update, "❌ Balance is 0 — cannot build steps.")
        return
    await _show_trade_summary(update)


async def _receive_step_amount(
    update: Update, text: str, ctx: ContextTypes.DEFAULT_TYPE
) -> None:
    state_manager = _sess(_uid(update)).state
    try:
        amount = float(text.replace(",", ""))
        if amount <= 0:
            raise ValueError
    except ValueError:
        await _reply(update, "❌ Please enter a valid positive amount.")
        return

    balance = state_manager.stats.current_balance
    valid, reason = risk_manager.validate_step_amount(amount, balance)
    if not valid:
        await _reply(update, f"❌ {reason}\nPlease enter a different amount:")
        return

    state_manager.config.step_amounts.append(amount)
    state_manager.config.current_step_input += 1

    if state_manager.config.current_step_input <= state_manager.config.step_count:
        idx = state_manager.config.current_step_input
        await _reply(update, f"💵 *Step {idx}* — bet amount? _(in ৳)_")
    else:
        await _show_trade_summary(update)


async def _show_trade_summary(update: Update) -> None:
    sm      = _sess(_uid(update)).state
    bal     = sm.stats.current_balance
    target  = sm.config.target_profit
    steps   = sm.config.step_count
    amounts = sm.config.step_amounts

    # Build step plan block
    plan_lines = []
    total_risk = sum(amounts)
    for i, amt in enumerate(amounts, 1):
        bar = "█" * min(10, max(1, round(amt / max(amounts) * 10)))
        plan_lines.append(f"  Step {i:02d}  {bar:<10}  ৳ {amt:.2f}")
    plan_block = "\n".join(plan_lines)

    period = _current_period()
    timer  = _timer()
    tbar   = _timer_bar(timer)

    text = (
        f"╔══════════════════════════╗\n"
        f"║  ⚙️  {TXT_CONFIG}  ⚙️  ║\n"
        f"╚══════════════════════════╝\n\n"
        f"{BANNER}\n"
        f"💰 *Balance*    : `৳ {bal:.2f}`\n"
        f"🎯 *Target*     : `৳ {target:.2f}` profit\n"
        f"🏦 *Stop At*    : `৳ {sm.config.target_balance:.2f}`\n"
        f"📋 *Steps*      : `{steps}`\n"
        f"⚠️ *Total Risk* : `৳ {total_risk:.2f}`\n"
        f"{BANNER}\n\n"
        f"📊 *STEP PLAN:*\n"
        f"```\n{plan_block}\n```\n\n"
        f"⏱️ *Current Period*\n"
        f"   `{period}`\n"
        f"   [{tbar}] `{timer}s`\n\n"
        f"{BANNER}\n"
        f"🧠 *Engine*: 9 layers + live backtest\n"
        f"🛑 *Confidence gate*: below `{settings.MIN_CONFIDENCE}%` → sit out\n"
        f"🎬 *Prediction animation*: `{settings.PREDICTION_ANIM_SECONDS:.0f}s`\n\n"
        f"👇 Press *START TRADE* to begin."
    )

    await _reply(update, text, reply_markup=start_cancel_keyboard())
    await sm.set_state(BotState.READY)


# ════════════════════════════════════════════════════════════════════════════
#   START / CANCEL TRADE CALLBACKS
# ════════════════════════════════════════════════════════════════════════════

async def _execute_start_trade(
    query, ctx: ContextTypes.DEFAULT_TYPE, uid: int
) -> None:
    sess          = _sess(uid)
    state_manager = sess.state
    trade_manager = sess.trade
    sm = state_manager
    if sm.get_state() != BotState.READY:
        await query.answer("⚠️ Not ready to trade yet.", show_alert=True)
        return

    sm.current_step = 1
    await sm.set_state(BotState.TRADING)

    period = _current_period()
    timer  = _timer()
    tbar   = _timer_bar(timer)

    chat_id = query.message.chat.id
    sess.chat_id = chat_id

    async def notify(msg: str) -> None:
        await _send_to(ctx, chat_id, msg)

    async def anim_start(text: str):
        return await _send_to(ctx, chat_id, text)

    async def anim_edit(msg, text: str) -> None:
        await _edit_text(msg, text)

    trade_manager.set_notify(notify)
    trade_manager.set_animator(anim_start, anim_edit)
    await trade_manager.start("AUTO")

    steps_summary = "\n".join(
        f"  Step {i+1:02d}  ➤  ৳ {a:.2f}"
        for i, a in enumerate(sm.config.step_amounts)
    )

    await query.message.reply_text(
        f"╔══════════════════════════╗\n"
        f"║  🚀  {TXT_TRADE}  🚀   ║\n"
        f"╚══════════════════════════╝\n\n"
        f"{BANNER}\n"
        f"💰 *Balance*  : `৳ {sm.config.starting_balance:.2f}`\n"
        f"🎯 *Target*   : `৳ {sm.config.target_profit:.2f}` profit\n"
        f"🏦 *Stop At*  : `৳ {sm.config.target_balance:.2f}`\n"
        f"📋 *Steps*    : `{sm.config.step_count}`\n"
        f"{BANNER}\n\n"
        f"📊 *Step Plan:*\n"
        f"```\n{steps_summary}\n```\n\n"
        f"⏱️ *Current Period*\n"
        f"   `{period}`\n"
        f"   [{tbar}] `{timer}s`\n\n"
        f"{BANNER}\n"
        f"🧠 *Analysing market…*\n"
        f"🎬 _4-second prediction animation → auto bet every period._",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu_keyboard(),
    )


async def _execute_cancel_trade(query, uid: int) -> None:
    sess          = _sess(uid)
    state_manager = sess.state
    hgnice_api    = sess.api

    await state_manager.set_state(BotState.LOGGED_IN)
    try:
        balance = await hgnice_api.get_balance(
            fallback=state_manager.stats.current_balance
        )
        state_manager.stats.current_balance = balance
    except HGNiceAPIError:
        balance = state_manager.stats.current_balance

    await query.message.reply_text(
        f"{BANNER}\n"
        f"❌ *TRADE CANCELLED*\n"
        f"{BANNER}\n\n"
        f"💰 Balance : `৳ {balance:.2f}`\n\n"
        f"Returned to main menu.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu_keyboard(),
    )
