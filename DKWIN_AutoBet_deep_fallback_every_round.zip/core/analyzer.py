"""17 pattern layers, latest-10 signals, past-only calibration and holdout checks.
Scores are heuristic evidence scores, NOT probabilities or guaranteed wins.
A long run alone does not make reversal due; detectors need measured support.
"""
from __future__ import annotations
import logging
import time
from datetime import datetime, timedelta
from typing import Optional
from config.settings import settings
from services.wingo_api import wingo_api

logger = logging.getLogger(__name__)
BIG, SMALL = "BIG", "SMALL"
LAST_N = 10

def _opp(side):
    return SMALL if side == BIG else BIG

def _r_four_run(seq, r):
    # The oldest run can be clipped by the ten-draw window.
    prior_four = r[2] == 4 or (len(seq) == 10 and r[2] >= 2 and sum(r[:3]) == 10)
    if r[1] == 4 and prior_four and r[0] <= 4:
        return seq[-1] if r[0] < 4 else _opp(seq[-1])
    return None


def _r_suffix(seq, r):
    # Repeated suffixes of length 3-5 with an observed successor.
    for width in (5, 4, 3):
        key = seq[-width:]
        successors = [seq[i + width] for i in range(len(seq) - width)
                      if seq[i:i + width] == key]
        if len(successors) >= 2 and len(set(successors)) == 1:
            return successors[0]
    return None


def _r_momentum(seq, r):
    if len(seq) < 10:
        return None
    recent, older = seq[-5:].count(BIG), seq[-10:-5].count(BIG)
    if recent >= 4 and recent - older >= 2:
        return BIG
    if recent <= 1 and older - recent >= 2:
        return SMALL
    return None


def _r_change_point(seq, r):
    if len(seq) < 10:
        return None
    older, recent = seq[-10:-3], seq[-3:]
    if len(set(recent)) == 1 and older.count(_opp(recent[-1])) >= 5:
        return recent[-1]
    return None


def _runs_newest_first(seq: list[str]) -> list[int]:
    """Run lengths, newest run first. ``seq`` is oldest -> newest."""
    runs: list[int] = []
    prev = None
    for x in reversed(seq):
        if runs and x == prev:
            runs[-1] += 1
        else:
            runs.append(1)
        prev = x
    return runs


# Each rule: seq (oldest -> newest, <=10 items) -> next side or None
def _r_zigzag(seq, r):
    return _opp(seq[-1]) if r[0] == 1 and r[1] == 1 and r[2] == 1 else None

def _r_zigzag_trap(seq, r):
    # 4+ alternations then a fresh pair -> zigzag broke, follow new run
    if r[0] == 2 and r[1] == 1 and r[2] == 1 and r[3] == 1:
        return seq[-1]
    return None

def _r_dragon(seq, r):
    return seq[-1] if 4 <= r[0] <= 6 else None

def _r_dragon_trap(seq, r):
    return _opp(seq[-1]) if r[0] >= 7 else None

def _r_tan(seq, r):
    return seq[-1] if r[0] in (2, 3) and r[1] >= 2 else None

def _r_big_trend(seq, r):
    return BIG if len(seq) >= 8 and seq.count(BIG) >= 7 and r[0] < 7 else None

def _r_small_trend(seq, r):
    return SMALL if len(seq) >= 8 and seq.count(SMALL) >= 7 and r[0] < 7 else None

def _r_double(seq, r):
    if r[1] == 2 and r[2] == 2 and r[0] <= 2:
        return seq[-1] if r[0] == 1 else _opp(seq[-1])
    return None

def _r_triple(seq, r):
    if r[1] == 3 and r[2] == 3 and r[0] <= 3:
        return seq[-1] if r[0] < 3 else _opp(seq[-1])
    return None

def _r_two_one(seq, r):
    # ... AA B AA B  (runs 1,2,1,2) -> after B comes AA
    if r[1] == 2 and r[2] == 1 and r[3] == 2:
        if r[0] == 1:
            return _opp(seq[-1])
        if r[0] == 2:
            return _opp(seq[-1])
    return None

def _r_one_two(seq, r):
    # ... A BB A BB (runs 2,1,2,1)
    if r[1] == 1 and r[2] == 2 and r[3] == 1:
        if r[0] == 1:
            return seq[-1]
        if r[0] == 2:
            return _opp(seq[-1])
    return None

def _r_mirror(seq, r):
    for L in (6, 4):
        if len(seq) > L:
            w = seq[-L:]
            if w == w[::-1] and len(set(w)) > 1:
                return seq[-L - 1]
    return None

def _r_markov(seq, r):
    if len(seq) < 6:
        return None
    key = tuple(seq[-2:])
    cnt = {BIG: 0, SMALL: 0}
    for i in range(len(seq) - 2):
        if tuple(seq[i:i + 2]) == key:
            cnt[seq[i + 2]] += 1
    if cnt[BIG] == cnt[SMALL]:
        return None
    return BIG if cnt[BIG] > cnt[SMALL] else SMALL


RULES = [
    ("DRAGON_TRAP", _r_dragon_trap), ("DRAGON", _r_dragon),
    ("ZIGZAG_TRAP", _r_zigzag_trap), ("ZIGZAG", _r_zigzag),
    ("TRIPLE", _r_triple), ("DOUBLE", _r_double),
    ("TWO_ONE", _r_two_one), ("ONE_TWO", _r_one_two),
    ("BIG_TREND", _r_big_trend), ("SMALL_TREND", _r_small_trend),
    ("TAN", _r_tan), ("MIRROR", _r_mirror), ("MARKOV", _r_markov),
    ("FOUR_RUN", _r_four_run), ("SUFFIX", _r_suffix),
    ("MOMENTUM", _r_momentum), ("CHANGE_POINT", _r_change_point),
]
RULE_FN = dict(RULES)


def _fire(seq: list[str]) -> list[tuple[str, str]]:
    if len(seq) < 3:
        return []
    r = _runs_newest_first(seq) + [0, 0, 0, 0]
    out = []
    for key, fn in RULES:
        p = fn(seq, r)
        if p:
            out.append((key, p))
    return out



LAYER_ORDER = tuple(RULE_FN)


def _rule_stats(history):
    """L1 calibration only: each vote uses exactly the preceding ten draws."""
    stats = {key: [0, 0] for key in LAYER_ORDER}
    start = max(LAST_N, len(history) - settings.ANALYSIS_BACKTEST)
    for t in range(start, len(history)):
        for key, pred in _fire(history[t - LAST_N:t]):
            stats[key][1] += 1
            stats[key][0] += int(pred == history[t])
    return stats


def _decision(seq, past):
    """Rank BIG/SMALL from 17 layers plus historical analogues and recent structure.

    For a valid 10-draw window this always emits one side. The evidence score is
    a heuristic ranking index, not a probability or guarantee. Exact equality
    is resolved inside the composite ranking using historical analogues,
    calibrated rule performance, recency-weighted evidence, then the latest
    observed side as a final deterministic criterion.
    """
    seq = list(seq[-LAST_N:])  # oldest -> newest
    if len(seq) != LAST_N or any(x not in (BIG, SMALL) for x in seq):
        raise ValueError("A valid ten-draw BIG/SMALL window is required")

    history = list(past)
    stats = _rule_stats(history)
    fired = dict(_fire(seq))
    rows = {}
    vote = {BIG: 0.0, SMALL: 0.0}
    calibration_edge = {BIG: 0.0, SMALL: 0.0}

    # 17 pattern layers: modestly calibrate a rule only when enough past
    # examples exist; this prevents a tiny sample from dominating the vote.
    for key in LAYER_ORDER:
        hits, samples = stats[key]
        rate = (hits + 2.0) / (samples + 4.0)
        pred = fired.get(key)
        if pred:
            edge = max(-0.20, min(0.20, rate - 0.5)) if samples >= 8 else 0.0
            weight = 1.0 + edge
            vote[pred] += weight
            calibration_edge[pred] += edge
        else:
            weight = 0.0
        rows[key] = {
            "prediction": pred,
            "hits": hits,
            "samples": samples,
            "accuracy": hits / samples if samples else None,
            "weight": round(weight, 4) if pred else 0.0,
        }

    active = len(fired)
    counts = {
        BIG: sum(p == BIG for p in fired.values()),
        SMALL: sum(p == SMALL for p in fired.values()),
    }

    # Recency-weighted composition of all ten recent outcomes.
    recency = {BIG: 0.0, SMALL: 0.0}
    for i, side in enumerate(seq):
        weight = 0.40 + 0.075 * i
        vote[side] += weight
        recency[side] += weight

    # Short trend and current run structure.
    runs = _runs_newest_first(seq)
    latest = seq[-1]
    last5 = seq[-5:]
    big5, small5 = last5.count(BIG), last5.count(SMALL)
    if big5 >= 4:
        vote[BIG] += 1.10
    elif small5 >= 4:
        vote[SMALL] += 1.10
    elif big5 > small5:
        vote[BIG] += 0.25
    elif small5 > big5:
        vote[SMALL] += 0.25

    if runs and runs[0] >= 2:
        # Continuation signal scales gently and is capped to avoid assuming
        # a streak must continue or reverse.
        vote[latest] += min(0.90, 0.18 * runs[0])

    # Detect alternation in the latest four/five draws and score the observed
    # successor of matching historical fragments.
    if len(seq) >= 4 and all(seq[i] != seq[i + 1] for i in range(len(seq) - 4, len(seq) - 1)):
        vote[_opp(latest)] += 0.45

    # Historical analogue model: look for matching recent suffixes (length 2-5)
    # in older history, and count what followed those matches. Do not use the
    # current ten-draw window as its own training example.
    past_context = history[:-LAST_N] if len(history) >= LAST_N and history[-LAST_N:] == seq else history
    analogue = {BIG: 0.0, SMALL: 0.0}
    analogue_samples = {BIG: 0, SMALL: 0}
    for width in (5, 4, 3, 2):
        if len(seq) < width:
            continue
        pattern = tuple(seq[-width:])
        for i in range(0, len(past_context) - width):
            if tuple(past_context[i:i + width]) == pattern:
                successor = past_context[i + width]
                if successor in analogue:
                    # Recent historical matches are slightly more relevant.
                    recency_factor = 0.75 + 0.25 * ((i + width) / max(1, len(past_context)))
                    analogue[successor] += recency_factor
                    analogue_samples[successor] += 1
    # Longer matching contexts get more weight, but only when supported by data.
    if sum(analogue_samples.values()) > 0:
        analogue_total = sum(analogue.values())
        if analogue_total:
            for side in (BIG, SMALL):
                vote[side] += 1.25 * analogue[side] / analogue_total

    # Two-side transition model from historical draws before the current window.
    transition = {BIG: 0.0, SMALL: 0.0}
    for i in range(0, max(0, len(past_context) - 2)):
        if tuple(past_context[i:i + 2]) == tuple(seq[-2:]):
            successor = past_context[i + 2]
            if successor in transition:
                transition[successor] += 1.0
    transition_total = sum(transition.values())
    if transition_total:
        for side in (BIG, SMALL):
            vote[side] += 0.90 * transition[side] / transition_total

    # Compare historical rule performance for each side among currently active
    # layers; smoothing keeps small samples from creating extreme weights.
    side_skill = {BIG: 0.0, SMALL: 0.0}
    for key, pred in fired.items():
        hits, samples = stats[key]
        smoothed = (hits + 2.0) / (samples + 4.0)
        side_skill[pred] += (smoothed - 0.5) * min(1.0, samples / 20.0)
    for side in (BIG, SMALL):
        vote[side] += side_skill[side] * 0.60

    # One unified ranking tuple ensures a prediction for every valid window.
    # Each component is observed evidence; the final latest-side criterion is
    # deterministic only if all measurable evidence is exactly equal.
    def ranking(side):
        return (
            round(vote[side], 10),
            round(analogue[side], 10),
            round(transition[side], 10),
            round(side_skill[side], 10),
            round(recency[side], 10),
            1 if latest == side else 0,
        )

    pred = BIG if ranking(BIG) > ranking(SMALL) else SMALL
    total = vote[BIG] + vote[SMALL]
    share = max(vote[BIG], vote[SMALL]) / total if total > 0 else 0.5
    margin = abs(vote[BIG] - vote[SMALL])
    # Signal-strength index only; deliberately not labelled as win probability.
    score = max(50, min(90, round(50 + 40 * share * min(1.0, margin / 3.0))))
    leaders = [
        (row["weight"], key_name) for key_name, row in rows.items()
        if row["prediction"] == pred and row["weight"] > 0
    ]
    key_name = max(leaders)[1] if leaders else "DEEP_LAST10_ENSEMBLE"

    return {
        "key": key_name,
        "prediction": pred,
        "confidence": score,
        "layers": rows,
        "active": active,
        "agree": counts[pred],
        "share": share,
        "skip": False,
        "reason": "Deep last-10 ensemble: 17 layers, historical suffix analogues, transitions, calibrated rule skill and recency structure; score is not a probability or guarantee",
        "evidence": {
            "big_score": round(vote[BIG], 4),
            "small_score": round(vote[SMALL], 4),
            "big_analogue_weight": round(analogue[BIG], 4),
            "small_analogue_weight": round(analogue[SMALL], 4),
            "big_transition_samples": int(transition[BIG]),
            "small_transition_samples": int(transition[SMALL]),
            "tie_resolved_by": (
                "composite evidence ranking" if abs(vote[BIG] - vote[SMALL]) >= 1e-9
                else "historical and recency evidence hierarchy"
            ),
        },
    }


def _holdout(history):
    """Re-run the COMPLETE engine on a held-out tail, never using future draws.
    L2 means the next eligible engine vote after L1 loss; skip is not a win.
    Only completed two-vote cycles enter the L2 denominator.
    """
    hits = bets = cycles = cycle_hits = 0
    pending = False
    for t in range(max(40, len(history) - 20), len(history)):
        d = _decision(history[t - LAST_N:t], history[:t])
        if d["skip"]:
            continue
        won = d["prediction"] == history[t]
        bets += 1
        hits += won
        if pending:
            cycles += 1
            cycle_hits += won
            pending = False
        elif won:
            cycles += 1
            cycle_hits += 1
        else:
            pending = True
    return {"hits": hits, "bets": bets, "cycle_hits": cycle_hits, "cycles": cycles,
            "l1": hits / bets if bets >= 10 else None,
            "l2": cycle_hits / cycles if cycles >= 10 else None}


def catchAndPredictPattern(sides_newest_first, history_newest_first=None):
    sides = sides_newest_first[:LAST_N]
    hist = (history_newest_first if history_newest_first is not None else sides_newest_first)
    if any(x not in (BIG, SMALL) for x in hist + sides):
        raise ValueError("Invalid BIG/SMALL history")
    if history_newest_first is not None and hist[:len(sides)] != sides:
        raise ValueError("History window does not match current draws")
    history = list(reversed(hist))
    d = _decision(list(reversed(sides)), history)
    check = _holdout(history)
    d.update({"holdout": check, "l2": round(check["l2"] * 100) if check["l2"] is not None else None})
    if len(history) < 50:
        d["low_history"] = True
        d["reason"] = "10-draw mode: limited history; prediction is experimental, not a verified edge"
    return d


def next_period(period):
    if len(period) >= 8 and period[8:].startswith("10005"):
        day, suffix = period[:8], period[8:]
        index = int(suffix) - 100050000 + 1
        if index > 2880:
            day = (datetime.strptime(day, "%Y%m%d") + timedelta(days=1)).strftime("%Y%m%d")
            index = 1
        return f"{day}{100050000 + index}"
    return str(int(period) + 1).zfill(len(period))


async def fetch_history(total):
    out, seen = [], set()
    for page in range(1, 7):
        chunk = await wingo_api.get_latest_results(page=page, page_size=min(50, total))
        if not chunk:
            break
        for draw in chunk:
            if draw.issue_number not in seen:
                seen.add(draw.issue_number)
                out.append(draw)
        if len(out) >= total:
            break
    # Some API responses/pages may not preserve newest-first ordering. Period IDs
    # are fixed-width numeric strings, so descending lexical order is chronological.
    out.sort(key=lambda item: item.issue_number, reverse=True)
    return out[:total]


def _history_features(numbers_newest_first: list[int]) -> dict:
    """Readable recent-history signals; descriptive evidence, not guarantees."""
    numbers = [int(n) for n in numbers_newest_first if 0 <= int(n) <= 9]
    sides = [BIG if n >= 5 else SMALL for n in numbers]
    recent5 = sides[:5]
    recent10 = sides[:10]
    if not sides:
        return {}

    streak_side = sides[0]
    streak_len = 1
    while streak_len < len(sides) and sides[streak_len] == streak_side:
        streak_len += 1
    previous_side = sides[streak_len] if streak_len < len(sides) else None
    streak_break = bool(streak_len == 1 and previous_side and previous_side != streak_side)

    big5, small5 = recent5.count(BIG), recent5.count(SMALL)
    big10, small10 = recent10.count(BIG), recent10.count(SMALL)
    if big5 >= 4:
        trend = BIG
        trend_basis = "4+ of last 5"
    elif small5 >= 4:
        trend = SMALL
        trend_basis = "4+ of last 5"
    elif big10 >= 7:
        trend = BIG
        trend_basis = "7+ of last 10"
    elif small10 >= 7:
        trend = SMALL
        trend_basis = "7+ of last 10"
    else:
        trend = None
        trend_basis = "No clear trend"

    zigzag4 = len(recent5) >= 4 and all(recent5[i] != recent5[i + 1] for i in range(3))
    zigzag5 = len(recent5) >= 5 and all(recent5[i] != recent5[i + 1] for i in range(4))
    last5_text = " ".join(f"{n}({'B' if n >= 5 else 'S'})" for n in numbers[:5]) or "N/A"
    last10_text = " ".join(f"{n}({'B' if n >= 5 else 'S'})" for n in numbers[:10]) or "N/A"
    # Work out the observed sequence structure without treating it as certainty.
    side_seq = sides[:10]
    side_text = "-".join("B" if side == BIG else "S" for side in side_seq)
    chronological = list(reversed(side_seq))
    runs = []
    for side in chronological:
        label = "B" if side == BIG else "S"
        if runs and runs[-1][0] == label:
            runs[-1][1] += 1
        else:
            runs.append([label, 1])
    run_text = " ".join(f"{side}{length}" for side, length in reversed(runs)) or "N/A"

    transitions = {"BIG→BIG": 0, "BIG→SMALL": 0, "SMALL→BIG": 0, "SMALL→SMALL": 0}
    # sides arrive newest-first; adjacent pairs still represent consecutive draws.
    for newer, older in zip(side_seq, side_seq[1:]):
        key = f"{older}→{newer}"
        if key in transitions:
            transitions[key] += 1
    transition_text = " | ".join(f"{key} {value}" for key, value in transitions.items())

    # Search for a repeated ending (length 2–4) and report its observed next side.
    repeated_pattern = "No repeated suffix with a clear successor"
    for width in (4, 3, 2):
        if len(side_seq) <= width:
            continue
        suffix = side_seq[:width]  # newest-first pattern
        successors = []
        for i in range(1, len(side_seq) - width):
            if side_seq[i:i + width] == suffix:
                # The side immediately before this older occurrence is its successor
                # when reading newest-first (the following chronological result).
                successors.append(side_seq[i - 1])
        if len(successors) >= 1:
            b_count = successors.count(BIG)
            s_count = successors.count(SMALL)
            repeated_pattern = (f"last {width} sides matched earlier; next-side samples "
                                f"BIG {b_count}/ {len(successors)}, SMALL {s_count}/ {len(successors)}")
            break

    number_counts = {n: numbers[:10].count(n) for n in range(10)}
    repeated_digits = sorted(((count, digit) for digit, count in number_counts.items() if count >= 2), reverse=True)
    digit_text = ", ".join(f"{digit}×{count}" for count, digit in repeated_digits[:4]) or "No digit repeated"

    return {
        "current_streak": streak_side,
        "streak_length": streak_len,
        "streak_break": streak_break,
        "trend_follow": trend,
        "trend_basis": trend_basis,
        "zigzag": zigzag5 or zigzag4,
        "recent5_numbers": numbers[:5],
        "recent10_numbers": numbers[:10],
        "big5": big5, "small5": small5,
        "big10": big10, "small10": small10,
        "last5_text": last5_text,
        "last10_text": last10_text,
        "side_sequence": side_text,
        "run_pattern": run_text,
        "transitions": transitions,
        "transition_text": transition_text,
        "repeated_pattern": repeated_pattern,
        "repeated_digits": digit_text,
        "dominance": BIG if big10 > small10 else SMALL if small10 > big10 else "BALANCED",
    }


async def fetchAndAnalyzeHistory():
    start = time.perf_counter()
    try:
        results = await fetch_history(settings.ANALYSIS_HISTORY)
        if len(results) < 10:
            raise ValueError(f"API returned only {len(results)} usable results; at least 10 are required")
        numbers = [int(r.number) for r in results]
        if any(n < 0 or n > 9 for n in numbers):
            raise ValueError("Invalid draw digit: expected values 0-9")

        # Validate the newest contiguous run. Older pages can occasionally have
        # a gap; that should not invalidate a sufficiently long recent run.
        contiguous = len(results)
        for i, (newer, older) in enumerate(zip(results, results[1:])):
            if next_period(older.issue_number) != newer.issue_number:
                contiguous = i + 1
                logger.warning(
                    "WinGo history gap/order issue between periods %s and %s; "
                    "using newest contiguous segment of %s draws",
                    newer.issue_number, older.issue_number, contiguous
                )
                break
        results = results[:contiguous]
        numbers = numbers[:contiguous]
        if len(results) < 10:
            raise ValueError(
                f"Only {len(results)} consecutive results available; at least 10 required"
            )
        sides = [BIG if n >= 5 else SMALL for n in numbers]
        d = catchAndPredictPattern(sides[:LAST_N], sides)
        rows = []
        for i, (key, layer) in enumerate(d["layers"].items(), 1):
            p = layer["prediction"] or "WAIT"
            acc = f"{layer['accuracy']:.0%}" if layer["accuracy"] is not None else "N/A"
            rows.append(f"{i:02d}. {key.replace('_', ' ')}: {p} | {acc} / {layer['samples']}")
        hold = d["holdout"]
        l2 = f"{d['l2']}% ({hold['cycles']} cycles)" if d["l2"] is not None else "insufficient completed cycles"
        features = _history_features(numbers)
        streak_label = f"{features['current_streak']} × {features['streak_length']}"
        trend_label = features['trend_follow'] or "NO CLEAR TREND"
        break_label = "YES — latest side changed" if features['streak_break'] else "NO / not confirmed"
        zigzag_label = "ACTIVE" if features['zigzag'] else "NOT ACTIVE"
        dominance_label = (f"{features['dominance']} ({features['big10']} BIG / {features['small10']} SMALL)")
        report = (f"📜 RECENT 5: `{features['last5_text']}`\n"
                  f"📜 RECENT 10: `{features['last10_text']}`\n"
                  f"🔥 CURRENT STREAK: {streak_label}\n"
                  f"🧩 STREAK BREAK: {break_label}\n"
                  f"📈 TREND FOLLOW: {trend_label} ({features['trend_basis']})\n"
                  f"🔢 STREAK LENGTH: {features['streak_length']}\n"
                  f"🔁 ZIGZAG / ALTERNATE: {zigzag_label}\n"
                  f"🧬 SIDE SEQUENCE (newest→oldest): {features['side_sequence']}\n"
                  f"🪜 RUN PATTERN: {features['run_pattern']}\n"
                  f"🔀 TRANSITIONS: {features['transition_text']}\n"
                  f"🧩 REPEATED PATTERN: {features['repeated_pattern']}\n"
                  f"🔢 REPEATED DIGITS: {features['repeated_digits']}\n"
                  f"⚖️ BIG/SMALL DOMINANCE: {dominance_label}\n"
                  f"🧠 *17-LAYER ANALYSIS* · {d['agree']}/{d['active']} agree\n"
                  + "\n".join(rows)
                  + f"\n📊 Holdout L1: {hold['hits']}/{hold['bets']} bets"
                  + f"\n🛡 Historical L2: {l2}"
                  + "\n⚠️ These are history-based indicators, not guaranteed wins or reliable probabilities.")
        d.update({"history_features": features,
                  "structure": d["key"], "pattern": d["key"],
                  "report": report, "detail": d["reason"] or d["key"].replace("_", " "),
                  "samples": len(results), "latest_period": results[0].issue_number,
                  "elapsed_ms": round((time.perf_counter() - start) * 1000)})
        return d["prediction"], d
    except Exception as exc:
        api_error = getattr(wingo_api, "last_error", None)
        error_text = f"{type(exc).__name__}: {exc}"
        if api_error:
            error_text += f" | API: {api_error}"
        logger.warning("Analysis unavailable: %s", error_text, exc_info=True)
        return SMALL, {"prediction": SMALL, "confidence": 0, "skip": True,
                       "structure": "API ERROR" if api_error else "ANALYSIS ERROR",
                       "detail": error_text,
                       "error": error_text,
                       "report": f"❌ *{ 'API ERROR' if api_error else 'ANALYSIS ERROR' }*\n`{error_text[:700]}`\n⚠️ History not verified; no bet this round.",
                       "layers": {}, "active": 0, "agree": 0, "samples": 0}


async def analyse_market():
    return await fetchAndAnalyzeHistory()
