"""
Per-user session registry.

Every authorized Telegram user gets their own isolated session:

    • StateManager     — FSM state, trading config, statistics
    • HGNiceAPIClient  — tokens, wallets, bet placement
    • TradeManager     — an independent trading loop

Nothing is shared between users, so several people can log in with
their own HGNICE account and run a target at the same time without
clobbering each other's session.
"""

import logging
from dataclasses import dataclass
from typing import Dict, Optional

from core.state_manager import StateManager, state_for
from core.trade_manager import TradeManager, trade_for
from services.hgnice_api import HGNiceAPIClient, client_for

logger = logging.getLogger(__name__)


@dataclass
class UserSession:
    uid: int
    state: StateManager
    api: HGNiceAPIClient
    trade: TradeManager
    chat_id: Optional[int] = None


_sessions: Dict[int, UserSession] = {}


def get_session(uid: int) -> UserSession:
    """Return (creating on first use) the session owned by ``uid``."""
    sess = _sessions.get(uid)
    if sess is None:
        sess = UserSession(
            uid=uid,
            state=state_for(uid),
            api=client_for(uid),
            trade=trade_for(uid),
        )
        _sessions[uid] = sess
        logger.info("Created session for telegram user %s", uid)
    return sess


def session_for(uid: int) -> Optional[UserSession]:
    """Return the session for ``uid`` if it already exists, else None."""
    return _sessions.get(uid)


def session_count() -> int:
    """How many distinct users have touched this bot since startup."""
    return len(_sessions)
