"""
WinGo 30S Result API client.
Uses the confirmed public API:
  https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json

Confirmed JSON response structure (from live API):
{
  "data": {
    "list": [
      {
        "issueNumber": "20261002100051550",
        "number": "9",
        "color": "green",
        "premium": "9",
        "sum": 0
      },
      ...
    ],
    "pageNo": 1,
    "totalPage": 50,
    "totalCount": 500
  },
  "code": 0,
  "msg": "Succeed",
  "msgCode": 0,
  "serviceTime": 1790945697388
}
"""

import logging
from typing import Optional

import httpx

from config.settings import settings

logger = logging.getLogger(__name__)

HISTORY_URL = settings.WINGO_HISTORY_URL


class WinGoResult:
    """Represents a single WinGo 30S result record."""

    def __init__(self, data: dict) -> None:
        self.issue_number: str = str(data.get("issueNumber", ""))
        self.number: str = str(data.get("number", ""))
        self.color: str = str(data.get("color", ""))
        self.premium: str = str(data.get("premium", ""))
        self.sum_val: int = int(data.get("sum", 0))

    def is_big(self) -> bool:
        """5-9 = BIG"""
        try:
            return int(self.number) >= 5
        except ValueError:
            return False

    def is_small(self) -> bool:
        """0-4 = SMALL"""
        try:
            return int(self.number) <= 4
        except ValueError:
            return False

    def is_green(self) -> bool:
        return "green" in self.color.lower()

    def is_red(self) -> bool:
        return "red" in self.color.lower()

    def is_violet(self) -> bool:
        return "violet" in self.color.lower()

    def __repr__(self) -> str:
        return (
            f"WinGoResult(issue={self.issue_number}, "
            f"number={self.number}, color={self.color})"
        )


class WinGoAPIClient:
    """Async client for the WinGo 30S public result API."""

    def __init__(self) -> None:
        self._client: Optional[httpx.AsyncClient] = None
        self.last_error: Optional[str] = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=settings.HTTP_TIMEOUT,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                                  "Chrome/131.0.0.0 Safari/537.36",
                    "Accept": "application/json, text/plain, */*",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Referer": settings.HGNICE_BASE_URL.rstrip("/") + "/",
                    "Origin": settings.HGNICE_BASE_URL.rstrip("/"),
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                    "Sec-Fetch-Dest": "empty",
                    "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Site": "cross-site",
                },
            )
        return self._client

    async def get_latest_results(self, page: int = 1, page_size: int = 10) -> list[WinGoResult]:
        """
        Fetch recent WinGo 30S results.
        Returns a list of WinGoResult objects, most recent first.
        """
        try:
            self.last_error = None
            client = await self._get_client()
            params = {"pageNo": page, "pageSize": page_size}
            # A couple of retries help with transient gateway/network failures.
            # A persistent 403 usually means the upstream blocks this server/IP;
            # headers cannot guarantee that the upstream will allow the request.
            last_error = None
            for attempt in range(3):
                try:
                    response = await client.get(HISTORY_URL, params=params)
                    response.raise_for_status()
                    payload = response.json()
                    if not isinstance(payload, dict):
                        raise ValueError("WinGo API returned a non-object JSON payload")
                    if payload.get("code") != 0:
                        self.last_error = f"API code={payload.get('code')!r}, msg={payload.get('msg')!r}"
                        logger.warning("WinGo API returned %s", self.last_error)
                        return []
                    data = payload.get("data") or {}
                    records = data.get("list") if isinstance(data, dict) else None
                    if not isinstance(records, list):
                        self.last_error = "Invalid API response: missing data.list array"
                        logger.warning("WinGo API response has no data.list array")
                        return []
                    parsed = []
                    for row in records:
                        if not isinstance(row, dict):
                            continue
                        result = WinGoResult(row)
                        if result.issue_number and result.number != "":
                            parsed.append(result)
                    if not parsed:
                        self.last_error = "API returned no usable history records"
                    return parsed
                except httpx.HTTPStatusError as exc:
                    last_error = exc
                    status = exc.response.status_code
                    body = (exc.response.text or "")[:180].replace("\n", " ")
                    self.last_error = f"HTTP {status}: {body or str(exc)}"
                    if status == 403 or status < 500 or attempt == 2:
                        logger.error(
                            "WinGo API HTTP error: %s; url=%s; body=%r",
                            status, str(exc.request.url), body
                        )
                        return []
                    logger.warning("WinGo API HTTP %s on attempt %s/3; retrying", status, attempt + 1)
                except (httpx.TimeoutException, httpx.TransportError, ValueError) as exc:
                    last_error = exc
                    self.last_error = f"{type(exc).__name__}: {exc}"
                    if attempt == 2:
                        logger.error("WinGo API request/parse failed after 3 attempts: %s", exc)
                        return []
                    logger.warning("WinGo API attempt %s/3 failed: %s", attempt + 1, exc)
            if last_error:
                logger.error("WinGo API failed: %s", last_error)
            return []
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            logger.exception("WinGo API unexpected error: %s", exc)
            return []

    async def get_result_for_period(self, period_id: str) -> Optional[WinGoResult]:
        """
        Poll for the result of a specific period.
        Returns None if the result is not yet available.
        """
        results = await self.get_latest_results(page_size=20)
        for result in results:
            if result.issue_number == period_id:
                return result
        return None

    async def get_latest_period(self) -> Optional[str]:
        """Return the most recent issued period number from the API."""
        results = await self.get_latest_results(page_size=1)
        if results:
            return results[0].issue_number
        return None

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


wingo_api = WinGoAPIClient()
