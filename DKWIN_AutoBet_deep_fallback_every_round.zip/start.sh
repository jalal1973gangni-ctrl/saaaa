#!/usr/bin/env bash
set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

mkdir -p logs storage

if [ -d "venv" ]; then
    source venv/bin/activate
fi

python3 main.py
