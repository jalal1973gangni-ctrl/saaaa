# HGNICE Auto Trade Bot — main.py rewrite (corrected)
import asyncio
import logging
import sys
import signal
from pathlib import Path
import os

sys.path.insert(0, str(Path(__file__).parent))

from config.settings import settings
from config.logging_config import setup_logging
from bot.application import create_application
from storage.database import init_database


async def _health_server():
    """Render Web Service needs an open port; answer simple HTTP 200."""
    port = os.environ.get("PORT")
    if not port:
        return None

    async def handle(reader, writer):
        try:
            await reader.read(1024)
            writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK")
            await writer.drain()
        finally:
            writer.close()

    server = await asyncio.start_server(handle, "0.0.0.0", int(port))
    logging.getLogger(__name__).info("Health server listening on port %s", port)
    return server


async def _error_handler(update, context) -> None:
    from telegram.error import Conflict
    log = logging.getLogger(__name__)
    if isinstance(context.error, Conflict):
        log.warning("Another bot instance is using this BOT_TOKEN. Waiting for it to stop...")
        return
    log.error("Unhandled error: %s", context.error, exc_info=context.error)


async def main() -> None:
    setup_logging()
    logger = logging.getLogger(__name__)
    logger.info("=" * 60)
    logger.info("HGNICE WinGo 30S Auto Trade Bot starting...")
    logger.info("=" * 60)
    settings.validate()
    await init_database(settings.OWNER_ID)
    logger.info("Database initialized.")
    health = await _health_server()
    app = await create_application()
    app.add_error_handler(_error_handler)
    logger.info("Bot is running. Press Ctrl+C to stop.")
    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except (NotImplementedError, RuntimeError):
            pass  # Windows uses KeyboardInterrupt.
    async with app:
        # Remove any webhook so polling does not conflict with it.
        await app.bot.delete_webhook(drop_pending_updates=True)
        await app.start()
        await app.updater.start_polling(
            drop_pending_updates=True,
            error_callback=lambda e: logging.getLogger(__name__).warning(
                "Polling issue: %s", e
            ),
        )
        try:
            await stop_event.wait()
        except (KeyboardInterrupt, SystemExit):
            pass
        finally:
            await app.updater.stop()
            await app.stop()
            if health:
                health.close()
    logger.info("Bot stopped.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
