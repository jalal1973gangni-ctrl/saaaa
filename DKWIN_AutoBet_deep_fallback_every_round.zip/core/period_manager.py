"""
Period manager for WinGo 30-second periods.
Uses UTC time to calculate and validate period IDs.
"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class PeriodManager:
    """Calculates WinGo 30S period IDs from UTC time."""

    @staticmethod
    def calculate_period(dt: datetime | None = None) -> str:
        """
        Calculate the WinGo 30S period ID from UTC datetime.

        Formula (provided by owner + verified against API):
            totalMinutesToday = (hours * 60) + minutes
            periodNumber = (totalMinutesToday * 2) + (1 if seconds < 30 else 2)
            period_id = f"{YYYYMMDD}10005{periodNumber:04d}"

        The API issues follow the format: 20261002100051550
        Breakdown:  20261002  +  10005  +  1550
                    YYYYMMDD  +  10005  +  periodNumber(4-digit)
        """
        if dt is None:
            dt = datetime.now(timezone.utc)

        year = dt.year
        month = dt.month
        day = dt.day
        hours = dt.hour
        minutes = dt.minute
        seconds = dt.second

        total_minutes = (hours * 60) + minutes
        period_number = (total_minutes * 2) + (1 if seconds < 30 else 2)

        date_str = f"{year:04d}{month:02d}{day:02d}"
        period_id = f"{date_str}10005{period_number:04d}"

        return period_id

    @staticmethod
    def timer_value(dt: datetime | None = None) -> int:
        """Returns seconds remaining in the current 30-second window (0-29)."""
        if dt is None:
            dt = datetime.now(timezone.utc)
        return 30 - (dt.second % 30)

    @staticmethod
    def validate_against_api(calculated: str, api_issue: str) -> bool:
        """
        Compare client-calculated period against the authoritative API issue number.
        Note: The API issue from GetHistoryIssuePage is the LATEST SETTLED period.
        The active betting period is therefore (api_issue + 1).
        """
        try:
            expected_active = int(api_issue) + 1
            calc_int = int(calculated)
            # Calculated period matches expected active, or +1 if API settlement is delayed
            match = calc_int in (expected_active, expected_active + 1)
            if not match:
                logger.warning(
                    "PERIOD MISMATCH! Calculated=%s  API settled=%s (Expected active=%s)",
                    calculated, api_issue, expected_active
                )
            return match
        except Exception as exc:
            logger.warning("Error comparing periods: %s", exc)
            return True


period_manager = PeriodManager()
