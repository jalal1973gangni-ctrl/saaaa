#!/usr/bin/env bash
# Automatic systemd service installer for 24/7 background operation
set -e

APP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
SERVICE_NAME="autotrade"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
CURRENT_USER="$(whoami)"
PYTHON_EXEC="${APP_DIR}/venv/bin/python"

if [ ! -f "${PYTHON_EXEC}" ]; then
    PYTHON_EXEC="$(which python3)"
fi

echo "Creating systemd service for Auto Trade Bot..."
echo "Working Directory: ${APP_DIR}"
echo "User: ${CURRENT_USER}"
echo "Python Executable: ${PYTHON_EXEC}"

sudo bash -c "cat << 'EOF' > ${SERVICE_FILE}
[Unit]
Description=HGNICE WinGo 30S Auto Trade Telegram Bot
After=network.target

[Service]
Type=simple
User=${CURRENT_USER}
WorkingDirectory=${APP_DIR}
ExecStart=${PYTHON_EXEC} main.py
Restart=always
RestartSec=5
StandardOutput=append:${APP_DIR}/logs/bot.log
StandardError=append:${APP_DIR}/logs/bot.log

[Install]
WantedBy=multi-user.target
EOF"

echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

echo "Enabling service on system boot..."
sudo systemctl enable ${SERVICE_NAME}

echo "Starting service..."
sudo systemctl restart ${SERVICE_NAME}

echo "=========================================="
echo "✅ Auto Trade Bot is now running 24/7 as a service!"
echo "Useful commands:"
echo "  Check status : sudo systemctl status ${SERVICE_NAME}"
echo "  View logs    : tail -f ${APP_DIR}/logs/bot.log"
echo "  Restart bot  : sudo systemctl restart ${SERVICE_NAME}"
echo "  Stop bot     : sudo systemctl stop ${SERVICE_NAME}"
echo "=========================================="
