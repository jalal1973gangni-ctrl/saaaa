import os
import runpy
import unittest
from pathlib import Path
from unittest.mock import patch
import yaml

ROOT = Path(__file__).resolve().parents[1]

class DeploymentTests(unittest.TestCase):
    def test_render_single_worker_and_persistent_disk(self):
        service = yaml.safe_load((ROOT / 'render.yaml').read_text())['services'][0]
        self.assertEqual(service['type'], 'worker')
        self.assertEqual(service['runtime'], 'docker')
        self.assertEqual(service['numInstances'], 1)
        self.assertEqual(service['disk']['mountPath'], '/app/storage')
        env = {r['key']: r for r in service['envVars']}
        self.assertFalse(env['BOT_TOKEN']['sync'])
        self.assertNotIn('value', env['BOT_TOKEN'])
        self.assertEqual(env['DATABASE_PATH']['value'], '/app/storage/bot_data.db')

    def test_no_secrets_or_runtime_db_in_source(self):
        import ast
        tree = ast.parse((ROOT / 'config/settings.py').read_text())
        tokens = [n for n in ast.walk(tree) if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and n.target.id == 'BOT_TOKEN']
        self.assertEqual(tokens[0].value.args[1].value, '')
        self.assertFalse((ROOT / '.env').exists())
        self.assertEqual(list((ROOT / 'storage').glob('*.db*')), [])
