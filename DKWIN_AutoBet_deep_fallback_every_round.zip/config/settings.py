"""
Telegram bot setup. Add a fresh BotFather token directly to BOT_TOKEN below.
HGNice phone number and password are entered in Telegram only.
"""

import os
from dotenv import load_dotenv

load_dotenv()
from pathlib import Path


class Settings:
    # --- Telegram ---
    # Paste a NEW, valid token from @BotFather between the quotes below.
    # The previously shared token was rejected by Telegram and will not work.
    BOT_TOKEN: str = "PASTE_NEW_BOTFATHER_TOKEN_HERE"
    OWNER_ID: int = 5692586257

    # --- HGNICE: account number/password are entered in Telegram only ---
    HGNICE_BASE_URL: str = os.getenv("HGNICE_BASE_URL", "https://hgnice9.com")

    # --- WinGo Result API ---
    WINGO_HISTORY_URL: str = (
        "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json"
    )

    # --- SQLite database path ---
    DATABASE_PATH: str = os.getenv(
        "DATABASE_PATH",
        str(Path(__file__).parent.parent / "storage" / "bot_data.db"),
    )

    # --- Polling intervals (seconds) ---
    RESULT_POLL_INTERVAL: float = float(os.getenv("RESULT_POLL_INTERVAL", "5"))
    HEALTH_CHECK_INTERVAL: float = float(os.getenv("HEALTH_CHECK_INTERVAL", "60"))

    # --- Timeouts ---
    HTTP_TIMEOUT: float = float(os.getenv("HTTP_TIMEOUT", "15"))

    # --- Trade lock timeout ---
    TRADE_LOCK_TIMEOUT: float = float(os.getenv("TRADE_LOCK_TIMEOUT", "25"))

    # --- Max result wait ---
    MAX_RESULT_WAIT: int = int(os.getenv("MAX_RESULT_WAIT", "120"))

    # --- Prediction engine -----------------------------------------------
    # How many recent WinGo draws are pulled for analysis.
    ANALYSIS_HISTORY: int = 10  # Analyze the latest 10 draws for the next period
    # How many walk-forward samples are used to back-test every layer.
    ANALYSIS_BACKTEST: int = int(os.getenv("ANALYSIS_BACKTEST", "100"))
    # Confidence gate: periods below this % are skipped (0 = never skip).
    MIN_CONFIDENCE: int = int(os.getenv("MIN_CONFIDENCE", "55"))

    # --- Prediction animation --------------------------------------------
    # Length in seconds of the "generating prediction" animation.
    PREDICTION_ANIM_SECONDS: float = float(os.getenv("PREDICTION_ANIM_SECONDS", "4"))

    # --- Log directory ---
    LOG_DIR: Path = Path(os.getenv("LOG_DIR", str(Path(__file__).parent.parent / "logs")))
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    def validate(self) -> None:
        if not self.BOT_TOKEN:
            raise ValueError("Paste your fresh BotFather token into config/settings.py (BOT_TOKEN).")
        if self.OWNER_ID <= 0:
            raise ValueError("OWNER_ID must be a positive Telegram user ID in config/settings.py.")


settings = Settings()
