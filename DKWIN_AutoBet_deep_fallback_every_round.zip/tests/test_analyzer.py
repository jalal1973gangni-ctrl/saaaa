import itertools
import random
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from core import analyzer as a
from core.trade_manager import should_sit_out
from config.settings import settings


def sides(pattern):
    return [a.BIG if c == 'B' else a.SMALL for c in pattern]


class AnalysisTests(unittest.TestCase):
    def test_exactly_17_distinct_layers(self):
        self.assertEqual(len(a.RULES), 17)
        self.assertEqual(len(set(a.LAYER_ORDER)), 17)

    def test_exhaustive_ten_draw_windows_do_not_crash(self):
        for seq in itertools.product((a.BIG, a.SMALL), repeat=10):
            self.assertTrue(all(p in (a.BIG, a.SMALL) for _, p in a._fire(list(seq))))

    def test_zigzag_detects_alternation(self):
        self.assertIn(('ZIGZAG', a.BIG), a._fire(sides('BSBSBSBSBS')))

    def test_zigzag_break_follows_fresh_pair(self):
        self.assertIn(('ZIGZAG_TRAP', a.BIG), a._fire(sides('BSBSBSBSBB')))

    def test_four_four_continues_then_switches(self):
        self.assertIn(('FOUR_RUN', a.BIG), a._fire(sides('BBBBSSSSBB')))
        self.assertIn(('FOUR_RUN', a.SMALL), a._fire(sides('BBSSSSBBBB')))

    def test_layers_use_only_latest_ten_for_current_signal(self):
        recent = sides('BSBSBSBSBS')[::-1]
        d = a.catchAndPredictPattern(recent, recent + sides('B' * 80))
        expected = dict(a._fire(recent[::-1]))
        self.assertEqual({k: v['prediction'] for k, v in d['layers'].items() if v['prediction']}, expected)

    def test_ten_draws_alone_force_sitout(self):
        d = a.catchAndPredictPattern(sides('BSBSBSBSBS'))
        self.assertTrue(d['skip'])
        self.assertIsNone(d['l2'])

    def test_backtest_uses_only_past_ten(self):
        history = sides('BS' * 30)
        with patch.object(a, '_fire', wraps=a._fire) as fire:
            a._rule_stats(history)
        self.assertEqual([call.args[0] for call in fire.call_args_list],
                         [history[t-10:t] for t in range(10, len(history))])

    def test_holdout_never_sees_future(self):
        history = sides('BS' * 60)
        with patch.object(a, '_decision', wraps=a._decision) as decide:
            a._holdout(history)
        self.assertEqual([call.args[1] for call in decide.call_args_list],
                         [history[:t] for t in range(100,120)])

    def test_unfinished_l2_not_counted(self):
        history = [a.BIG] * 41
        with patch.object(a, '_decision', return_value={'skip': False, 'prediction': a.SMALL}):
            d = a._holdout(history)
        self.assertEqual(d['bets'], 1)
        self.assertEqual(d['cycles'], 0)
        self.assertIsNone(d['l2'])

    def test_l2_uses_next_engine_vote_not_opposite_fallback(self):
        history = [a.BIG] * 42
        with patch.object(a, '_decision', return_value={'skip': False, 'prediction': a.SMALL}):
            d = a._holdout(history)
        self.assertEqual(d['cycles'], 1)
        self.assertEqual(d['cycle_hits'], 0)

    def test_sitouts_are_not_wins(self):
        with patch.object(a, '_decision', return_value={'skip': True}):
            d = a._holdout(sides('BS'*60))
        self.assertEqual(d['bets'], 0)
        self.assertEqual(d['cycles'], 0)

    def test_uncertainty_gate_cannot_be_disabled_for_invalid_data(self):
        with patch.object(settings, 'MIN_CONFIDENCE', 0):
            self.assertTrue(should_sit_out({'skip': True, 'confidence': 99}, '123'))
            self.assertTrue(should_sit_out({'confidence': 99}, '123'))
            self.assertTrue(should_sit_out({'confidence': 99, 'latest_period': '120'}, '123'))
            self.assertFalse(should_sit_out({'confidence': 99, 'latest_period': '122'}, '123'))

    def test_confidence_gate_uses_configured_threshold(self):
        with patch.object(settings, 'MIN_CONFIDENCE', 55):
            self.assertTrue(should_sit_out({'confidence': 54, 'latest_period': '122'}, '123'))
            self.assertFalse(should_sit_out({'confidence': 55, 'latest_period': '122'}, '123'))

    def test_invalid_side_rejected(self):
        with self.assertRaises(ValueError):
            a.catchAndPredictPattern(['INVALID'] * 10)

    def test_no_probability_inflation_from_more_votes(self):
        d = a.catchAndPredictPattern(sides('BS' * 75))
        self.assertLessEqual(d['confidence'], 90)
        self.assertEqual(len(d['layers']), 17)


class FetchTests(unittest.IsolatedAsyncioTestCase):
    async def test_actual_entry_point_runs_seventeen_layers(self):
        results = [SimpleNamespace(issue_number=str(500-i), number=str(8 if i%2 else 2)) for i in range(150)]
        with patch.object(a, 'fetch_history', new_callable=AsyncMock, return_value=results):
            pred, meta = await a.analyse_market()
        self.assertIn(pred, (a.BIG, a.SMALL))
        self.assertEqual(len(meta['layers']), 17)
        self.assertFalse(meta['skip'])
        self.assertEqual(meta['latest_period'], '500')

    async def test_missing_history_fails_closed(self):
        with patch.object(a, 'fetch_history', new_callable=AsyncMock, return_value=[]):
            _, meta = await a.analyse_market()
        self.assertTrue(meta['skip'])
        self.assertEqual(meta['confidence'], 0)

    async def test_bad_digit_fails_closed(self):
        results = [SimpleNamespace(issue_number=str(500-i), number='10') for i in range(60)]
        with patch.object(a, 'fetch_history', new_callable=AsyncMock, return_value=results):
            _, meta = await a.analyse_market()
        self.assertTrue(meta['skip'])

    async def test_gap_in_history_fails_closed(self):
        results = [SimpleNamespace(issue_number=str(500-i*2), number='2') for i in range(60)]
        with patch.object(a, 'fetch_history', new_callable=AsyncMock, return_value=results):
            _, meta = await a.analyse_market()
        self.assertTrue(meta['skip'])

    async def test_repeated_api_pages_cannot_inflate_history(self):
        rows = [SimpleNamespace(issue_number=str(i)) for i in range(10)]
        with patch.object(a.wingo_api, 'get_latest_results', new_callable=AsyncMock, return_value=rows):
            results = await a.fetch_history(150)
        self.assertEqual(len(results), 10)
