# HGNICE — 17-layer Telegram bot

GitHub → Render instructions: [RENDER_SETUP_BN.md](RENDER_SETUP_BN.md).
The existing HGNICE/About menus, owner commands and per-user login remain.

## Run locally

Use Python 3.11 or later. Install dependencies with `pip install -r requirements.txt`.
Copy `.env.example` to `.env`; privately set `BOT_TOKEN` and `OWNER_ID`.
Run `python main.py`. On Windows use `RUN_WINDOWS.cmd` after filling `.env`.
Run tests with `python -m unittest discover -s tests -v`.

## Analysis

Exactly 17 detectors execute each round: Dragon break candidate, Dragon follow,
Zigzag break, Zigzag, Triple (3-3), Double (2-2), 2-1, 1-2, BIG trend, SMALL trend,
Tan follow, Mirror, second-order Markov, 4-4, repeated suffix, momentum shift,
and change point. Each can abstain. Current signals use the latest ten results;
up to 150 past results calibrate weights with past-only walk-forward evaluation.

Layers with fewer than six past fires or no smoothed edge over 50% get no weight.
Conflicting consensus, insufficient data, invalid digits, history gaps, stale periods,
timeouts, and missing or nonpositive held-out edge cause automatic sit-outs.
More layers do not necessarily improve accuracy: many share the same input and
are correlated. Evidence score is a heuristic, not a calibrated win probability.

The last 20 draws form a walk-forward holdout: each replay trains only on earlier
draws. Historical L2 uses the complete engine's next eligible vote after an L1
loss. Skips are not wins; unfinished cycles are omitted; fewer than ten completed
cycles is reported as insufficient. This is not a guarantee of a two-level win,
nor a profit estimate, and does not model fees/stake sizes. L2 does not change
the existing live stake ladder. Random outcomes remain unpredictable.

## Hosting and security

Use one Render Background Worker with the persistent disk in `render.yaml`.
Workers and disks are paid services; check Render's current prices before creating.
No HTTP port or keep-alive pinger is needed. Never run two polling processes with
the same token. A disk persists SQLite records, not in-memory account logins;
after restart log in again and manually restart trading. Keep database backups.
Never commit `.env`, tokens, databases or logs. Rotate any previously shared token
with BotFather before deployment. Passwords sent to bots are not end-to-end encrypted.

Automated tests use synthetic data and mocks. Real Telegram/HGNICE trading and
hosted Render startup are not verified by this archive's tests.


## Platform selection (HGNice + DKWIN login)

The home screen offers HGNice and DKWIN. DKWIN login uses `https://api.dkwinapi.com/api/webapi/Login` with `Ar-Origin: https://dkwin16.com` and `phonetype: 1`. HGNice keeps its original login endpoint and settings. The remaining history/trading endpoints are intentionally shared as requested; confirm with a small, non-betting API check that the target platform accepts the same endpoints before enabling real-money trading. Never paste account passwords, bearer tokens, refresh tokens, or cookies into chat or source control.
