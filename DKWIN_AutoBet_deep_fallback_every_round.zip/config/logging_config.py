﻿"""Logging configuration with rotating file handler and secret redaction."""

import logging
import logging.handlers
import re
from pathlib import Path

from config.settings import settings


_REDACT_PATTERNS = [
    (re.compile(r'(password["\s:=]+)[^\s,}\'"&]+', re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'(token["\s:=]+)[^\s,}\'"&]+', re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'(authorization["\s:=]+)[^\s,}\'"&]+', re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'(cookie["\s:=]+)[^\s,}\'"&]+', re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'(secret["\s:=]+)[^\s,}\'"&]+', re.IGNORECASE), r'\1[REDACTED]'),
]


class RedactingFilter(logging.Filter):
    """
    Filter that redacts sensitive data from log records.

    NOTE: only *string* arguments may be rewritten. The previous version
    converted every argument with str(), which broke every %-style log call
    that used %d / %f — e.g. "conf=%d" got the string '70' and Python raised
    "TypeError: %d format: a real number is required, not str", so those log
    lines were silently lost.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._redact(str(record.msg))
        if record.args:
            if isinstance(record.args, dict):
                record.args = {
                    k: (self._redact(v) if isinstance(v, str) else v)
                    for k, v in record.args.items()
                }
            else:
                record.args = tuple(
                    self._redact(a) if isinstance(a, str) else a
                    for a in record.args
                )
        return True

    @staticmethod
    def _redact(text: str) -> str:
        for pattern, replacement in _REDACT_PATTERNS:
            text = pattern.sub(replacement, text)
        return text


def setup_logging() -> None:
    """Configure application-wide logging."""
    log_dir = settings.LOG_DIR
    log_dir.mkdir(parents=True, exist_ok=True)

    log_level = getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(log_level)
    console_handler.addFilter(RedactingFilter())

    # Rotating file handler (10 MB, keep 5 backups)
    file_handler = logging.handlers.RotatingFileHandler(
        filename=log_dir / "bot.log",
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(log_level)
    file_handler.addFilter(RedactingFilter())

    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)

    # Silence noisy third-party loggers
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
