@echo off
setlocal
cd /d "%~dp0"
echo Copy .env.example to .env and set BOT_TOKEN and OWNER_ID before running.
if not exist venv\Scripts\python.exe (
    python -m venv venv
    if errorlevel 1 goto failed
)
venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
venv\Scripts\python.exe main.py
pause
exit /b
:failed
echo Setup failed. Check that Python is installed and available in CMD.
pause
exit /b 1