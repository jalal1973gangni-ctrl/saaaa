"""
Result checker: polls the WinGo API until the result for a given period
is available, then resolves WIN/LOSS based on the trade type.
"""

import asyncio
import logging
from typing import Optional

from config.settings import settings
from services.wingo_api import wingo_api, WinGoResult

logger = logging.getLogger(__name__)


def determine_outcome(result: WinGoResult, trade_type: str) -> tuple[str, float]:
    """
    Determine WIN or LOSS based on result and trade type.
    Returns (outcome: str, multiplier: float).

    WinGo 30S standard payout rules:
      - BIG / SMALL bets: ~1.98x (return) → profit multiplier ~0.98
      - RED / GREEN bets: ~1.98x
      - Number bets (0-9): ~9x
      - VIOLET (0 or 5):  ~4.5x

    TODO: Confirm exact payout multipliers from the HGNICE platform
          after observing live trades.
    """
    trade_upper = trade_type.upper()

    number = int(result.number) if result.number.isdigit() else -1
    color = result.color.lower()

    if trade_upper == "BIG":
        won = number >= 5
        multiplier = 0.98
    elif trade_upper == "SMALL":
        won = number <= 4
        multiplier = 0.98
    elif trade_upper == "RED":
        won = "red" in color and "violet" not in color
        multiplier = 0.98
    elif trade_upper == "GREEN":
        won = "green" in color and "violet" not in color
        multiplier = 0.98
    elif trade_upper == "VIOLET":
        won = "violet" in color
        multiplier = 3.5
    elif trade_upper.isdigit():
        won = result.number == trade_upper
        multiplier = 8.0
    else:
        logger.warning("Unknown trade type: %s. Cannot determine outcome.", trade_type)
        return "ERROR", 0.0

    outcome = "WIN" if won else "LOSS"
    return outcome, multiplier


class ResultChecker:
    """
    Polls the WinGo API until the result for a specific period is available.
    """

    async def wait_for_result(
        self,
        period_id: str,
        trade_type: str,
        amount: float,
        timeout: int | None = None,
        api=None,
    ) -> tuple[str, float]:
        """
        Wait for and return (outcome, profit) for the given period.

        Args:
            period_id: The WinGo 30S issue number.
            trade_type: e.g. "BIG", "SMALL", "RED", "GREEN".
            amount: The amount wagered.
            timeout: Max seconds to wait before returning "PENDING".
            api: The HGNiceAPIClient belonging to the betting user — used to
                 ask the server for the authoritative win/loss verdict.

        Returns:
            (outcome, profit) where outcome is "WIN", "LOSS", or "ERROR".
        """
        max_wait = timeout or settings.MAX_RESULT_WAIT
        poll_interval = settings.RESULT_POLL_INTERVAL
        waited = 0.0

        logger.info("Waiting for result of period %s (type=%s amount=%.2f)", period_id, trade_type, amount)

        while waited < max_wait:
            result = await wingo_api.get_result_for_period(period_id)
            if result is not None:
                # Issue has drawn! Check authoritative server outcome if logged in
                try:
                    if api is not None:
                        server_data = await api.get_win_loss_result(period_id)
                        if server_data and "status" in server_data:
                            is_win = bool(server_data.get("status"))
                            win_amount = float(server_data.get("winAmount") or 0.0)
                            outcome = "WIN" if is_win else "LOSS"
                            # winAmount is gross returned payout. Net profit = winAmount - bet amount
                            profit = round(win_amount - amount, 2) if is_win else -amount
                            logger.info(
                                "Server verified result for %s: outcome=%s, profit=%.2f",
                                period_id, outcome, profit,
                            )
                            return outcome, profit
                except Exception as exc:
                    logger.debug("Server GetWinLossResult check fallback to rule-based: %s", exc)

                outcome, multiplier = determine_outcome(result, trade_type)
                profit = round(amount * multiplier, 2) if outcome == "WIN" else -amount
                logger.info(
                    "Result for period %s: number=%s color=%s → %s (profit=%.2f)",
                    period_id, result.number, result.color, outcome, profit,
                )
                return outcome, profit

            await asyncio.sleep(poll_interval)
            waited += poll_interval

        logger.error("Timed out waiting for result of period %s", period_id)
        return "ERROR", 0.0


result_checker = ResultChecker()
