﻿"""
Risk manager: validates trade amounts against balance and step limits.
"""

import logging

logger = logging.getLogger(__name__)


class RiskManager:
    """Enforces money-management and safety rules before placing trades."""

    @staticmethod
    def validate_step_amount(amount: float, balance: float) -> tuple[bool, str]:
        """Validate a single step amount."""
        if amount <= 0:
            return False, "Amount must be greater than 0."
        if amount > balance:
            return False, f"Amount ৳{amount:.2f} exceeds current balance ৳{balance:.2f}."
        return True, ""

    @staticmethod
    def can_trade(
        current_balance: float,
        required_amount: float,
        current_step: int,
        max_steps: int,
    ) -> tuple[bool, str]:
        """
        Check whether it is safe to place the next trade.
        Returns (can_trade: bool, reason: str).
        """
        if current_step > max_steps:
            return False, f"Current step {current_step} exceeds max steps {max_steps}."
        if required_amount > current_balance:
            return False, (
                f"Insufficient balance. Need ৳{required_amount:.2f}, "
                f"have ৳{current_balance:.2f}."
            )
        return True, ""

    @staticmethod
    def is_target_reached(current_balance: float, target_balance: float) -> bool:
        return current_balance >= target_balance


risk_manager = RiskManager()


STEP_REBUILD_EVERY = 100.0   # rebuild steps each time balance grows by this much


def build_steps(balance: float, count: int) -> list[float]:
    """Doubling steps that together use the whole balance (Step Calculator logic)."""
    if balance <= 0 or count <= 0:
        return []
    first = balance / (2 ** count - 1)
    steps = [float(max(1, round(first * 2 ** i))) for i in range(count)]
    diff = round(balance) - sum(steps)
    steps[-1] = float(max(1, steps[-1] + diff))
    return steps
