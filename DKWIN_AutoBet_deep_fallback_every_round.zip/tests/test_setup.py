import ast
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

ROOT = Path(__file__).resolve().parents[1]


class SetupTests(unittest.IsolatedAsyncioTestCase):
    def test_empty_deployment_secrets_fail_validation(self):
        import runpy
        with patch.dict('os.environ', {'BOT_TOKEN': '', 'OWNER_ID': '0'}):
            settings = runpy.run_path(str(ROOT / 'config/settings.py'))['settings']
        self.assertEqual(settings.BOT_TOKEN, '')
        self.assertEqual(settings.OWNER_ID, 0)
        with self.assertRaises(ValueError):
            settings.validate()

    def test_render_environment_configures_bot(self):
        import runpy
        with patch.dict('os.environ', {'BOT_TOKEN': 'synthetic-test-token', 'OWNER_ID': '123'}):
            settings = runpy.run_path(str(ROOT / 'config/settings.py'))['settings']
        self.assertEqual(settings.BOT_TOKEN, 'synthetic-test-token')
        self.assertEqual(settings.OWNER_ID, 123)
        settings.validate()

    def test_no_startup_hgnice_credentials(self):
        tree = ast.parse((ROOT / 'config/settings.py').read_text())
        fields = {n.target.id for n in ast.walk(tree) if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)}
        self.assertNotIn('HGNICE_ACCOUNT', fields)
        self.assertNotIn('HGNICE_PASSWORD', fields)

    async def test_telegram_accepts_account_then_requests_password(self):
        from bot import handlers
        from bot.states import BotState
        session = SimpleNamespace(account_number='')
        state = SimpleNamespace(session=session, set_state=AsyncMock())
        update = SimpleNamespace(effective_user=SimpleNamespace(id=123))
        with patch.object(handlers, '_sess', return_value=SimpleNamespace(state=state)), patch.object(handlers, '_reply', new_callable=AsyncMock):
            await handlers._receive_account_number(update, '01700000000')
        self.assertEqual(session.account_number, '01700000000')
        state.set_state.assert_awaited_once_with(BotState.LOGIN_PASSWORD)

    async def test_telegram_password_sent_to_own_login_and_cleared(self):
        from bot import handlers
        from bot.states import BotState
        session = SimpleNamespace(account_number='01700000000', set_password=lambda value: setattr(session, 'password', value), get_password=lambda: session.password)
        state = SimpleNamespace(session=session, stats=SimpleNamespace(), set_state=AsyncMock())
        info = SimpleNamespace(account_masked='masked', user_id='test', nick_name='test', balance=0)
        api = SimpleNamespace(login=AsyncMock(return_value=info))
        message = SimpleNamespace(delete=AsyncMock(), reply_text=AsyncMock())
        update = SimpleNamespace(effective_user=SimpleNamespace(id=123), message=message)
        loading = SimpleNamespace(delete=AsyncMock())
        with patch.object(handlers, '_sess', return_value=SimpleNamespace(state=state, api=api)), patch.object(handlers, '_progress_loading', new_callable=AsyncMock, return_value=loading):
            await handlers._receive_password(update, 'synthetic-test-password')
        api.login.assert_awaited_once_with('01700000000', 'synthetic-test-password')
        self.assertEqual(session.password, '')
        message.delete.assert_awaited_once()
        state.set_state.assert_awaited_once_with(BotState.LOGGED_IN)


if __name__ == '__main__':
    unittest.main()