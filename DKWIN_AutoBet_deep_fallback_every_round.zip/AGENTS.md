# Bot maintenance
- Read BOT_TOKEN and OWNER_ID from environment variables; ship no credentials or existing databases so GitHub source remains safe.
- Collect HGNice credentials only through the per-user Telegram login flow to keep sessions isolated.
- Use exactly 17 registered pattern detectors with latest-10 signal windows and past-only calibration; report heuristic evidence separately from holdout results.
- Automatic trading must sit out invalid, stale, insufficient or conflicting signals regardless of the configurable score gate.
- Deploy a single Telegram polling process as a Render background worker with a persistent SQLite disk; multiple replicas would conflict.
