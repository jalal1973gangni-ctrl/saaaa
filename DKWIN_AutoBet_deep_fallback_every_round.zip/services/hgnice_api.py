"""
HGNICE API client for authentication, balance, trading, and account state.

Reverse-engineered and verified against live traffic on https://hgnice9.com/#/:
- Main Platform API: https://api.hgnicepayapi.com
- Lottery Game API:   https://api.ar-lottery01.com
"""

import base64
import hashlib
import json
import logging
import random
import time
import urllib.parse
import uuid
from dataclasses import dataclass
from typing import Optional, Any

import httpx

from config.settings import settings

logger = logging.getLogger(__name__)


@dataclass
class AccountInfo:
    account_number: str
    account_masked: str
    balance: float
    currency: str = "BDT"
    user_id: str = ""
    nick_name: str = ""
    raw: dict = None


class HGNiceAPIError(Exception):
    """Raised when the HGNICE API returns an error or fails."""
    def __init__(self, message: str, code: Any = None):
        super().__init__(message)
        self.code = code


def sign_main_request(data: dict) -> dict:
    """
    MD5 signature calculation for https://api.hgnicepayapi.com endpoints.
    Sorts non-empty keys alphabetically, serializes to compact JSON,
    and computes uppercase MD5.
    """
    d = dict(data)
    d.pop("signature", None)
    d.pop("timestamp", None)
    d["language"] = 0
    d["random"] = uuid.uuid4().hex
    filtered = {
        k: v for k, v in sorted(d.items())
        if v is not None and v != "" and k not in ["signature", "track", "xosoBettingData"]
    }
    json_str = json.dumps(filtered, separators=(',', ':'))
    d["signature"] = hashlib.md5(json_str.encode()).hexdigest().upper()
    d["timestamp"] = int(time.time())
    return d


def sign_lottery_request(params: dict) -> dict:
    """
    MD5 signature calculation for https://api.ar-lottery01.com lottery endpoints.
    Injects a 12-digit random integer, sorts non-empty keys alphabetically,
    serializes to compact JSON, and computes uppercase MD5.
    """
    p = dict(params)
    p.pop("signature", None)
    p.pop("timestamp", None)
    p["random"] = random.randint(100000000000, 999999999999)
    filtered = {
        k: v for k, v in sorted(p.items())
        if v is not None and v != "" and k != "signature"
    }
    json_str = json.dumps(filtered, separators=(',', ':'))
    p["signature"] = hashlib.md5(json_str.encode()).hexdigest().upper()
    p["timestamp"] = int(time.time())
    return p


class HGNiceAPIClient:
    """
    Async HTTP client for HGNICE WinGo 30S trading.
    Handles dual-token architecture:
      - Main token (api.hgnicepayapi.com)
      - Lottery token (api.ar-lottery01.com) with automatic rolling refresh
    """

    MAIN_API_BASE = "https://api.hgnicepayapi.com"
    LOTTERY_API_BASE = "https://api.ar-lottery01.com"
    ORIGIN = "https://hgnice9.com"

    LOGIN_ENDPOINT = f"{MAIN_API_BASE}/api/webapi/Login"
    ONLINE_STATUS_ENDPOINT = f"{MAIN_API_BASE}/api/webapi/UpdateOnlineStatus"
    # Moves the platform wallet balance into the game (ARGame) wallet.
    # hgnice9.com calls this right before a game is opened — without it the
    # lottery API keeps reporting the (empty) game wallet.
    TRANSFER_ENDPOINT = f"{MAIN_API_BASE}/api/webapi/Transfer"
    # Diagnostics: where the money actually sits.
    MAIN_USER_INFO_ENDPOINT = f"{MAIN_API_BASE}/api/webapi/GetUserInfo"
    WALLETS_ENDPOINT = f"{MAIN_API_BASE}/api/webapi/GetARGameAndPlatWallets"

    USER_INFO_ENDPOINT = f"{LOTTERY_API_BASE}/api/Lottery/GetUserInfo"
    BALANCE_ENDPOINT = f"{LOTTERY_API_BASE}/api/Lottery/GetBalance"
    BET_ENDPOINT = f"{LOTTERY_API_BASE}/api/Lottery/WinGoBet"
    WIN_LOSS_ENDPOINT = f"{LOTTERY_API_BASE}/api/Lottery/GetWinLossResult"
    HISTORY_ENDPOINT = f"{LOTTERY_API_BASE}/api/Lottery/GetHistoryIssuePage"
    TREND_ENDPOINT = f"{LOTTERY_API_BASE}/api/Lottery/GetTrendStatistics"

    def __init__(self, uid: int = 0) -> None:
        self._uid: int = uid
        self.platform: str = "hgnice"
        self.ORIGIN = type(self).ORIGIN
        self.LOGIN_ENDPOINT = f"{self.MAIN_API_BASE}/api/webapi/Login"
        self._client: Optional[httpx.AsyncClient] = None
        self._main_token: Optional[str] = None
        self._ar_token: Optional[str] = None
        self._user_id: Optional[str] = None
        self._nick_name: Optional[str] = None
        self._account_number: Optional[str] = None
        self._device_id: str = "45de5b6ba3062e1b4827ea21238ffe1a"

    def select_platform(self, platform: str) -> None:
        """Select platform login settings; other API endpoints remain shared."""
        platform = (platform or "hgnice").strip().lower()
        if platform not in {"hgnice", "dkwin"}:
            raise ValueError("Unsupported platform")
        if self.platform != platform:
            self.clear_session()
        self.platform = platform
        if platform == "dkwin":
            self.LOGIN_ENDPOINT = "https://api.dkwinapi.com/api/webapi/Login"
            self.ORIGIN = "https://dkwin16.com"
        else:
            self.LOGIN_ENDPOINT = f"{self.MAIN_API_BASE}/api/webapi/Login"
            self.ORIGIN = type(self).ORIGIN

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=settings.HTTP_TIMEOUT,
                headers={
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/120.0.0.0 Safari/537.36"
                    ),
                    "Accept-Language": "en-US,en;q=0.9",
                },
                follow_redirects=True,
            )
        return self._client

    def _check_token_refresh(self, response: httpx.Response) -> None:
        """Inspect response headers for updated bearer token and refresh rolling ar_token."""
        auth_hdr = response.headers.get("authorization") or response.headers.get("Authorization")
        if auth_hdr and auth_hdr.startswith("Bearer "):
            new_tok = auth_hdr[7:].strip()
            if new_tok and new_tok != self._ar_token:
                self._ar_token = new_tok
                logger.debug("Lottery token rotated from response header.")

    def clear_session(self) -> None:
        """Wipe all authentication tokens and state from memory."""
        self._main_token = None
        self._ar_token = None
        self._user_id = None
        self._nick_name = None
        self._account_number = None
        if self._client and not self._client.is_closed:
            import asyncio
            asyncio.create_task(self._client.aclose())
        self._client = None
        logger.info("%s session cleared from memory.", self.platform.upper())

    # ------------------------------------------------------------------ #
    #  PUBLIC API METHODS                                                #
    # ------------------------------------------------------------------ #

    async def login(self, account_number: str, password: str) -> AccountInfo:
        """
        Authenticate with HGNICE main API and initialize the lottery session.
        """
        masked = "****" + account_number[-4:] if len(account_number) >= 4 else "****"
        logger.info("Attempting %s login for account %s", self.platform.upper(), masked)

        payload = {
            "username": account_number,
            "pwd": password,
            "phonetype": 1 if self.platform == "dkwin" else 0,
            "logintype": "mobile",
            "deviceId": self._device_id,
            "packId": "",
            "pixelId": "",
            "fbcId": "",
            "fbc": "",
            "fbp": "",
            "adId": "",
        }
        signed = sign_main_request(payload)
        headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "Ar-Origin": self.ORIGIN,
        }

        client = await self._get_client()
        try:
            resp = await client.post(self.LOGIN_ENDPOINT, json=signed, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        except httpx.TimeoutException as exc:
            raise HGNiceAPIError("Login request timed out") from exc
        except httpx.HTTPStatusError as exc:
            raise HGNiceAPIError(f"Login failed (HTTP {exc.response.status_code})") from exc
        except Exception as exc:
            raise HGNiceAPIError(f"Login request error: {exc}") from exc

        if data.get("code") != 0:
            msg = data.get("msg", "Login failed")
            raise HGNiceAPIError(msg, code=data.get("code"))

        d = data.get("data", {})
        self._main_token = d.get("token")
        logger.debug("Login response data keys: %s", list(d.keys()))
        logger.debug("lotteryLoginUrl: %s", d.get("lotteryLoginUrl", "NOT FOUND"))

        # Extract user_id, nick_name, and balance from JWT claims
        self._user_id = ""
        self._nick_name = ""
        _jwt_balance: float = 0.0

        tokens_to_try = [self._main_token, d.get("refreshToken")]
        for tok in tokens_to_try:
            if not tok:
                continue
            try:
                parts = tok.split(".")
                if len(parts) >= 2:
                    padded = parts[1] + "==="
                    claims = json.loads(base64.urlsafe_b64decode(padded))
                    if not self._user_id:
                        self._user_id = str(claims.get("UserId") or claims.get("userId") or "")
                    if not self._nick_name:
                        self._nick_name = str(claims.get("NickName") or claims.get("nickName") or "")
                    # ── KEY FIX: balance is stored as "Amount" in the main JWT ──
                    if not _jwt_balance:
                        amt = claims.get("Amount") or claims.get("amount") or claims.get("Balance") or claims.get("balance")
                        if amt:
                            try:
                                _jwt_balance = float(amt)
                                logger.info("Balance extracted from JWT claims: %.2f", _jwt_balance)
                            except (TypeError, ValueError):
                                pass
            except Exception as e:
                logger.debug("Failed parsing JWT claims: %s", e)

        # Fallback to direct keys or webSocketChannels if still empty
        if not self._user_id:
            self._user_id = str(d.get("userId") or "")
            if not self._user_id and "webSocketChannels" in d:
                for ch in d.get("webSocketChannels", []):
                    if "/userid/" in ch:
                        self._user_id = ch.split("/userid/")[-1]
                        break

        if not self._nick_name:
            self._nick_name = str(d.get("nickName") or "")

        self._account_number = account_number

        # Extract ar_token from lotteryLoginUrl (case-insensitive key lookup)
        lottery_url = d.get("lotteryLoginUrl", "")
        if lottery_url:
            parsed = urllib.parse.urlparse(lottery_url)
            qs = urllib.parse.parse_qs(parsed.query)
            # Build a lowercase-keyed map so "Token", "token", "TOKEN" all match
            qs_lower = {k.lower(): v for k, v in qs.items()}
            token_val = qs_lower.get("token")
            if token_val:
                self._ar_token = token_val[0]
                logger.info("Lottery game token successfully extracted.")
            else:
                logger.warning("lotteryLoginUrl found but no 'token' param. Full URL: %s", lottery_url)

        if not self._ar_token:
            logger.warning("No lottery Token found in login response lotteryLoginUrl.")

        # ── Balance resolution ──────────────────────────────────────────────
        # TWO wallets exist (verified against a real traffic capture of
        # hgnice9.com, 2026-10-02):
        #   • PLATFORM wallet — JWT "Amount" / webapi/GetUserInfo.amount
        #   • GAME wallet     — lottery GetBalance & WinGoBet (ar-lottery01)
        # They are NOT the same number. The site sweeps the platform wallet
        # into the game wallet with webapi/Transfer before a game opens.
        balance = _jwt_balance  # platform wallet (may be 0.0)

        # Step 1 — platform wallet → game wallet.
        # Real traffic always POSTs /api/webapi/Transfer at this point; the
        # bot never did, which is why LOGIN showed ৳502.05 while every later
        # screen showed ৳0.00 (bets failed too: game wallet was empty).
        transfer_ok = await self.transfer_to_game()

        if self._ar_token:
            # Step 2 — activate the lottery session (token refresh) so the
            # first GetBalance returns a real value.
            await self._warm_lottery_session()
            try:
                live = await self.get_balance()  # raw value, no fallback yet
            except Exception as exc:
                logger.warning("Initial balance query failed: %s", exc)
                live = None

            if live is None:
                balance = _jwt_balance
            elif live <= 0 < _jwt_balance:
                # Transfer did not reach the game wallet — report it loudly,
                # then show the platform figure instead of a scary ৳0.00.
                logger.warning(
                    "Game wallet is empty (%.2f) while the platform wallet holds "
                    "%.2f — Transfer may have been rejected by the server.",
                    live, _jwt_balance,
                )
                balance = _jwt_balance
            else:
                balance = live

        # ── One-line wallet diagnosis (read this in the server console) ────
        overview = await self.get_wallet_overview()
        logger.info(
            "Wallet check → transfer=%s | platform=%s | arGame=%s | lottery=%s "
            "| game(GetBalance)=%s",
            "OK" if transfer_ok else "FAILED",
            overview["platform"], overview["arGame"], overview["lottery"],
            balance,
        )

        try:
            logger.info("Login successful for %s (UserId: %s, Balance: %.2f)", masked, self._user_id, float(balance))
        except (TypeError, ValueError):
            logger.info("Login successful for %s (UserId: %s, Balance: %s)", masked, self._user_id, balance)
        return AccountInfo(
            account_number=account_number,
            account_masked=masked,
            balance=balance,
            user_id=self._user_id,
            nick_name=self._nick_name,
            raw=d,
        )

    async def _main_post(self, endpoint: str, payload: Optional[dict] = None) -> dict:
        """Signed POST to the main platform API using the main bearer token."""
        if not self._main_token:
            raise HGNiceAPIError("Not logged in (no main token)")

        client = await self._get_client()
        signed = sign_main_request(payload or {})
        headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "Authorization": f"Bearer {self._main_token}",
            "Ar-Origin": self.ORIGIN,
        }
        try:
            resp = await client.post(endpoint, json=signed, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        except Exception as exc:
            raise HGNiceAPIError(f"Main API request failed: {exc}") from exc

        if data.get("code") != 0:
            raise HGNiceAPIError(
                data.get("msg", "Main API returned error"), code=data.get("code")
            )
        return data.get("data") or {}

    async def get_wallet_overview(self) -> dict:
        """
        Diagnostic: where does the money actually sit?

        Returns {"platform": float|None, "arGame": float|None, "lottery": float|None}.
        The platform wallet is what webapi/GetUserInfo.amount (and the JWT
        "Amount" claim) reports; arGame / lottery come from
        webapi/GetARGameAndPlatWallets; the lottery GetBalance is the wallet
        WinGoBet actually debits.
        """
        out: dict = {"platform": None, "arGame": None, "lottery": None}

        try:
            d = await self._main_post(self.MAIN_USER_INFO_ENDPOINT)
            out["platform"] = float(d.get("amount") or 0)
        except Exception as exc:
            logger.warning("Wallet overview (platform) failed: %s", exc)

        try:
            d = await self._main_post(self.WALLETS_ENDPOINT)
            for item in (d.get("thidGameBalanceList") or d.get("thirdGameBalanceList") or []):
                vendor = str(item.get("vendorCode", "")).lower()
                try:
                    value = float(item.get("balance") or 0)
                except (TypeError, ValueError):
                    continue
                if vendor == "argame":
                    out["arGame"] = value
                elif vendor == "lottery":
                    out["lottery"] = value
        except Exception as exc:
            logger.warning("Wallet overview (game wallets) failed: %s", exc)

        return out

    async def transfer_to_game(self) -> bool:
        """
        POST /api/webapi/Transfer (main API, signed, main bearer token).

        Moves the WHOLE platform-wallet balance into the game wallet used by
        api.ar-lottery01.com (WinGo / lottery). This is exactly what
        hgnice9.com does right before opening a game — mirrored from the real
        traffic capture: Transfer carries no amount, only the MD5 signature.

        Returns True when the server answered code=0.
        """
        if not self._main_token:
            logger.warning("Transfer skipped — no main token.")
            return False

        client = await self._get_client()
        signed = sign_main_request({})
        headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "Authorization": f"Bearer {self._main_token}",
            "Ar-Origin": self.ORIGIN,
        }

        try:
            resp = await client.post(self.TRANSFER_ENDPOINT, json=signed, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        except Exception as exc:
            logger.warning("Transfer failed (non-fatal): %s", exc)
            return False

        if data.get("code") != 0:
            logger.warning(
                "Transfer rejected by server: %s (code=%s)",
                data.get("msg"), data.get("code"),
            )
            return False

        logger.info("Platform wallet → game wallet transfer succeeded.")
        return True

    async def _warm_lottery_session(self) -> None:
        """
        Call GetUserInfo with the initial lottery token.
        The server responds with a REFRESHED token in the Authorization
        response header (LoginTime changes from negative → positive).
        _check_token_refresh() picks it up automatically.
        This must be called before the first GetBalance so the session
        is fully activated on the server side.
        """
        if not self._ar_token:
            return
        client = await self._get_client()
        params = sign_lottery_request({"language": "en"})
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Authorization": f"Bearer {self._ar_token}",
        }
        try:
            resp = await client.get(self.USER_INFO_ENDPOINT, params=params, headers=headers)
            resp.raise_for_status()
            self._check_token_refresh(resp)  # ← picks up refreshed token from response header
            logger.info("Lottery session warmed up (token refresh triggered).")
        except Exception as exc:
            logger.warning("Lottery session warm-up failed (non-fatal): %s", exc)

    async def get_balance(self, fallback: Optional[float] = None) -> float:
        """
        Fetch current account balance from lottery API.

        Args:
            fallback: last known good balance. When the API replies with an
                empty / zero value while a real balance is already known
                (lottery session not fully warmed up yet), that value is
                returned instead, so every screen keeps showing the real
                balance instead of flipping back to ৳0.00.
        """
        if not self._ar_token:
            raise HGNiceAPIError("Not logged in (no lottery session token)")

        client = await self._get_client()
        params = sign_lottery_request({"language": "en"})
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Authorization": f"Bearer {self._ar_token}",
        }

        try:
            resp = await client.get(self.BALANCE_ENDPOINT, params=params, headers=headers)
            resp.raise_for_status()
            self._check_token_refresh(resp)
            data = resp.json()
        except httpx.TimeoutException as exc:
            raise HGNiceAPIError("Balance query timed out") from exc
        except httpx.HTTPStatusError as exc:
            raise HGNiceAPIError(f"Balance check failed (HTTP {exc.response.status_code})") from exc
        except Exception as exc:
            raise HGNiceAPIError(f"Balance check error: {exc}") from exc

        if data.get("code") != 0:
            raise HGNiceAPIError(data.get("msg", "Balance query returned error"), code=data.get("code"))

        raw_data = data.get("data", {})
        bal_raw: Any
        if isinstance(raw_data, dict):
            # Try multiple possible field names (API may use any of these)
            bal_raw = None
            for key in (
                "balance", "Balance", "money", "Money", "amount", "Amount",
                "userBalance", "UserBalance", "balanceAmount", "BalanceAmount",
            ):
                val = raw_data.get(key)
                if val not in (None, ""):
                    bal_raw = val
                    break
        else:
            # API replied with a bare number / numeric string
            bal_raw = raw_data

        logger.debug("Balance API raw_data: %s", raw_data)

        if bal_raw in (None, ""):
            logger.warning("GetBalance response carries no balance field (data=%s)", data)
            bal = 0.0
        else:
            try:
                bal = float(bal_raw)
            except (TypeError, ValueError) as exc:
                raise HGNiceAPIError(f"Unexpected balance value: {bal_raw!r}") from exc

        if fallback is not None and bal <= 0 < fallback:
            logger.warning(
                "GetBalance returned %.2f while last known balance is %.2f — keeping last known.",
                bal, fallback,
            )
            return fallback

        return bal

    async def get_account_info(self) -> AccountInfo:
        """Fetch updated account information including balance."""
        if not self._account_number:
            raise HGNiceAPIError("No active account session")
        balance = await self.get_balance()
        masked = "****" + self._account_number[-4:] if len(self._account_number) >= 4 else "****"
        return AccountInfo(
            account_number=self._account_number,
            account_masked=masked,
            balance=balance,
            user_id=self._user_id or "",
            nick_name=self._nick_name or "",
        )

    async def place_trade(
        self,
        period_id: str,
        trade_type: str,
        amount: float,
    ) -> dict:
        """
        Place a WinGo 30S trade.

        Args:
            period_id: The 17-digit issue number (e.g. '20261003100051640')
            trade_type: ONLY 'BIG' or 'SMALL' are accepted.
            amount: Total bet value (৳). Base unit is 1, betMultiple is int(amount).

        Raises:
            HGNiceAPIError: If trade_type is not BIG or SMALL, or if API returns error.
        """
        if not self._ar_token:
            raise HGNiceAPIError("Not logged in (no lottery session token)")

        # Strict BIG/SMALL only — reject anything else
        t_upper = trade_type.upper()
        if t_upper not in ("BIG", "SMALL"):
            raise HGNiceAPIError(
                f"Invalid trade type '{trade_type}'. Only BIG and SMALL are allowed."
            )

        # Map to API betContent format
        bet_content = "BigSmall_Big" if t_upper == "BIG" else "BigSmall_Small"

        # Unit amount and multiple calculation
        # Base unit is 1 BDT, betMultiple is total units
        base_unit = 1
        multiple = max(1, int(round(amount)))

        payload = {
            "gameCode": "WinGo_30S",
            "issueNumber": str(period_id),
            "amount": base_unit,
            "betMultiple": multiple,
            "betContent": bet_content,
            "language": "en",
        }
        signed = sign_lottery_request(payload)

        headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._ar_token}",
        }

        logger.info(
            "Submitting trade: issue=%s content=%s units=%s (৳%s)",
            period_id, bet_content, multiple, base_unit * multiple,
        )

        client = await self._get_client()
        try:
            resp = await client.post(self.BET_ENDPOINT, json=signed, headers=headers)
            resp.raise_for_status()
            self._check_token_refresh(resp)
            data = resp.json()
        except httpx.TimeoutException as exc:
            raise HGNiceAPIError(f"Bet placement timed out for period {period_id}") from exc
        except httpx.HTTPStatusError as exc:
            raise HGNiceAPIError(
                f"Bet placement failed (HTTP {exc.response.status_code})",
                code=exc.response.status_code,
            ) from exc
        except Exception as exc:
            raise HGNiceAPIError(f"Bet placement error: {exc}") from exc

        if data.get("code") != 0:
            msg = data.get("msg", "Trade placement failed")
            raise HGNiceAPIError(msg, code=data.get("code"))

        order_id = str(signed.get("random", ""))
        logger.info("Trade successfully accepted: period=%s order=%s", period_id, order_id)
        return {
            "orderId": order_id,
            "issueNumber": period_id,
            "amount": amount,
            "raw": data,
        }

    async def get_win_loss_result(self, period_id: str) -> Optional[dict]:
        """
        Directly query server for win/loss result of a specific period.
        Returns dict with status (bool), winAmount (float) or None.
        """
        if not self._ar_token:
            return None

        client = await self._get_client()
        params = sign_lottery_request({
            "issueNumber": str(period_id),
            "language": "en",
        })
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Authorization": f"Bearer {self._ar_token}",
        }

        try:
            resp = await client.get(self.WIN_LOSS_ENDPOINT, params=params, headers=headers)
            resp.raise_for_status()
            self._check_token_refresh(resp)
            data = resp.json()
            if data.get("code") == 0:
                return data.get("data")
        except Exception as exc:
            logger.warning("GetWinLossResult query error: %s", exc)
        return None

    async def update_online_status(self) -> bool:
        """Send periodic online heartbeat to main API."""
        if not self._main_token:
            return False

        client = await self._get_client()
        signed = sign_main_request({})
        headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "Authorization": f"Bearer {self._main_token}",
            "Ar-Origin": self.ORIGIN,
        }

        try:
            resp = await client.post(self.ONLINE_STATUS_ENDPOINT, json=signed, headers=headers)
            resp.raise_for_status()
            return resp.json().get("code") == 0
        except Exception as exc:
            logger.debug("UpdateOnlineStatus error: %s", exc)
            return False

    async def logout(self) -> bool:
        """Clear all session data and tokens."""
        logger.info("[user %s] Logging out and clearing session...", self._uid)
        self.clear_session()
        return True

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# ── Per-user registry ────────────────────────────────────────────────────────

_clients: dict[int, HGNiceAPIClient] = {}


def client_for(uid: int) -> HGNiceAPIClient:
    """Return (creating on first use) the API client owned by ``uid``."""
    client = _clients.get(uid)
    if client is None:
        client = HGNiceAPIClient(uid)
        _clients[uid] = client
    return client