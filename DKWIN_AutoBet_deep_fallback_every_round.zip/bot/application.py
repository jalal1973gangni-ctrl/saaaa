"""
Build and configure the python-telegram-bot Application.
"""

import logging

from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    MessageHandler,
    filters,
)

from telegram.constants import ParseMode

from bot.handlers import (
    cmd_start,
    cmd_grant_access,
    cmd_remove_access,
    cmd_list_access,
    cmd_my_id,
    cmd_help,
    callback_handler,
    handle_text,
)
from config.settings import settings
from core.health_monitor import health_monitor

logger = logging.getLogger(__name__)


async def create_application() -> Application:
    """Create, configure and return the Telegram Application."""
    settings.validate()

    app = (
        Application.builder()
        .token(settings.BOT_TOKEN)
        .build()
    )

    # Commands — /hgnice and /rm are owner-only, checked inside the handlers
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("id", cmd_my_id))
    app.add_handler(CommandHandler("hgnice", cmd_grant_access))
    app.add_handler(CommandHandler("rm", cmd_remove_access))
    app.add_handler(CommandHandler("access", cmd_list_access))

    # Inline keyboard callbacks
    app.add_handler(CallbackQueryHandler(callback_handler))

    # Text messages
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    # Health alerts actually reach the owner now
    async def _health_notify(msg: str) -> None:
        try:
            await app.bot.send_message(
                settings.OWNER_ID, msg, parse_mode=ParseMode.MARKDOWN
            )
        except Exception as exc:
            logger.error("Health alert delivery failed: %s", exc)

    health_monitor.set_notify(_health_notify)
    health_monitor.start()

    logger.info("Telegram application configured.")
    return app
