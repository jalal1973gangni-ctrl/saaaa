﻿"""
Health monitor: periodic heartbeat that checks connections and notifies
the owner if something is wrong.
"""

import asyncio
import logging
from typing import Callable, Coroutine, Any, Optional

from config.settings import settings
from services.wingo_api import wingo_api

logger = logging.getLogger(__name__)

NotifyFn = Callable[[str], Coroutine[Any, Any, None]]


class HealthMonitor:
    def __init__(self) -> None:
        self._task: Optional[asyncio.Task] = None
        self._notify: Optional[NotifyFn] = None
        self._failure_counts: dict = {}

    def set_notify(self, fn: NotifyFn) -> None:
        self._notify = fn

    async def _send(self, msg: str) -> None:
        if self._notify:
            try:
                await self._notify(msg)
            except Exception as exc:
                logger.error("Health monitor notify failed: %s", exc)

    def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(self._loop(), name="health_monitor")
        logger.info("Health monitor started.")

    def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
        logger.info("Health monitor stopped.")

    async def _loop(self) -> None:
        interval = settings.HEALTH_CHECK_INTERVAL
        while True:
            try:
                await asyncio.sleep(interval)
                await self._check_wingo_api()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("Health monitor error: %s", exc)

    async def _check_wingo_api(self) -> None:
        results = await wingo_api.get_latest_results(page_size=1)
        key = "wingo_api"
        if not results:
            self._failure_counts[key] = self._failure_counts.get(key, 0) + 1
            logger.warning("WinGo API health check FAILED (%d)", self._failure_counts[key])
            if self._failure_counts[key] >= 3:
                await self._send(
                    "⚠️ *Health Alert*\n\n"
                    "WinGo result API has failed 3+ consecutive checks.\n"
                    "New trades will not be placed until it recovers."
                )
        else:
            if self._failure_counts.get(key, 0) > 0:
                logger.info("WinGo API recovered.")
                self._failure_counts[key] = 0


health_monitor = HealthMonitor()
