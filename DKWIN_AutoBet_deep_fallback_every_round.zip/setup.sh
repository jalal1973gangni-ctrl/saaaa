#!/usr/bin/env bash
# One-click setup script for Ubuntu/Debian on WishByte VPS
set -e

echo "=========================================="
echo "  HGNICE WinGo Auto Trade Bot Setup       "
echo "  WishByte VPS Auto Installer             "
echo "=========================================="

# 1. Update system packages
echo "[1/5] Updating system packages..."
sudo apt update -y

# 2. Install Python 3, pip and venv
echo "[2/5] Installing Python 3 and venv..."
sudo apt install -y python3 python3-pip python3-venv git curl

# 3. Create virtual environment
echo "[3/5] Setting up Python virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate

# 4. Install dependencies
echo "[4/5] Installing dependencies from requirements.txt..."
pip install --upgrade pip
pip install -r requirements.txt

# 5. Create storage & logs directories
echo "[5/5] Creating folders..."
mkdir -p logs storage

if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo "Created .env from .env.example. Please make sure to check your credentials in .env!"
    fi
fi

chmod +x start.sh

echo "=========================================="
echo "✅ Setup complete!"
echo "To test run the bot now: ./start.sh"
echo "To run 24/7 as a background service: sudo bash deploy/setup_service.sh"
echo "=========================================="
