﻿"""
SQLite database layer using aiosqlite.
Persists only safe (non-credential) trading state.

Multi-user layout
-----------------
Every table is keyed by ``user_id`` (the Telegram user id), so each
authorized user keeps an isolated session, trade history and stats.

The ``access_list`` table holds the Telegram ids the owner has granted
access to via ``/hgnice <id>`` (``/rm <id>`` revokes it).
"""

import logging
from pathlib import Path

import aiosqlite

from config.settings import settings

logger = logging.getLogger(__name__)

_DB_PATH = Path(settings.DATABASE_PATH)

# ── DDL ──────────────────────────────────────────────────────────────────────

_SESSION_STATE_DDL = """
    CREATE TABLE IF NOT EXISTS session_state (
        user_id INTEGER PRIMARY KEY,
        bot_state TEXT NOT NULL DEFAULT 'NOT_LOGGED_IN',
        current_step INTEGER NOT NULL DEFAULT 1,
        total_trades INTEGER NOT NULL DEFAULT 0,
        total_wins INTEGER NOT NULL DEFAULT 0,
        total_losses INTEGER NOT NULL DEFAULT 0,
        total_profit REAL NOT NULL DEFAULT 0.0,
        current_balance REAL NOT NULL DEFAULT 0.0,
        target_profit REAL NOT NULL DEFAULT 0.0,
        starting_balance REAL NOT NULL DEFAULT 0.0,
        target_balance REAL NOT NULL DEFAULT 0.0,
        last_traded_period TEXT NOT NULL DEFAULT '',
        last_order_id TEXT NOT NULL DEFAULT '',
        step_amounts TEXT NOT NULL DEFAULT '',
        step_count INTEGER NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
"""

_TRADES_DDL = """
    CREATE TABLE IF NOT EXISTS trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL DEFAULT 0,
        period_id TEXT NOT NULL,
        order_id TEXT,
        step INTEGER NOT NULL,
        amount REAL NOT NULL,
        trade_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'PENDING',
        result TEXT,
        profit REAL DEFAULT 0.0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE (user_id, period_id)
    );
"""

_STATISTICS_DDL = """
    CREATE TABLE IF NOT EXISTS statistics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL DEFAULT 0,
        session_date DATE NOT NULL DEFAULT (date('now')),
        starting_balance REAL NOT NULL DEFAULT 0.0,
        ending_balance REAL NOT NULL DEFAULT 0.0,
        target_profit REAL NOT NULL DEFAULT 0.0,
        total_trades INTEGER NOT NULL DEFAULT 0,
        total_wins INTEGER NOT NULL DEFAULT 0,
        total_losses INTEGER NOT NULL DEFAULT 0,
        total_profit REAL NOT NULL DEFAULT 0.0,
        outcome TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
"""

_ACCESS_DDL = """
    CREATE TABLE IF NOT EXISTS access_list (
        user_id INTEGER PRIMARY KEY,
        added_by INTEGER NOT NULL,
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
"""

# Columns carried over when a legacy (single-user) table is rebuilt.
_LEGACY_SESSION_COLS = [
    "bot_state", "current_step", "total_trades", "total_wins", "total_losses",
    "total_profit", "current_balance", "target_profit", "starting_balance",
    "target_balance", "last_traded_period", "last_order_id", "step_amounts",
    "step_count", "updated_at",
]
_LEGACY_TRADE_COLS = [
    "period_id", "order_id", "step", "amount", "trade_type", "status",
    "result", "profit", "created_at", "updated_at",
]
_LEGACY_STAT_COLS = [
    "session_date", "starting_balance", "ending_balance", "target_profit",
    "total_trades", "total_wins", "total_losses", "total_profit", "outcome",
    "created_at",
]


async def _columns(conn: aiosqlite.Connection, table: str) -> set[str]:
    cursor = await conn.execute(f"PRAGMA table_info({table})")
    rows = await cursor.fetchall()
    return {row[1] for row in rows}


async def _rebuild(
    conn: aiosqlite.Connection,
    table: str,
    ddl: str,
    columns: list[str],
    owner_id: int,
) -> None:
    """Recreate ``table`` with a ``user_id`` column, keeping old rows."""
    legacy = f"_legacy_{table}"
    await conn.execute(f"ALTER TABLE {table} RENAME TO {legacy}")
    await conn.execute(ddl)
    keep = ", ".join(columns)
    await conn.execute(
        f"INSERT OR IGNORE INTO {table} (user_id, {keep}) "
        f"SELECT ?, {keep} FROM {legacy}",
        (owner_id,),
    )
    await conn.execute(f"DROP TABLE {legacy}")
    logger.info("Migrated table '%s' to per-user layout.", table)


async def init_database(owner_id: int = 0) -> None:
    """Create all tables if they do not exist and migrate legacy schemas."""
    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    async with aiosqlite.connect(_DB_PATH) as conn:
        await conn.executescript("PRAGMA journal_mode=WAL;")
        await conn.executescript(
            _SESSION_STATE_DDL + _TRADES_DDL + _STATISTICS_DDL + _ACCESS_DDL
        )

        # ── Migrate single-user rows from older deployments ────────────────
        session_cols = await _columns(conn, "session_state")
        if "user_id" not in session_cols:
            await _rebuild(conn, "session_state", _SESSION_STATE_DDL,
                           _LEGACY_SESSION_COLS, owner_id)

        trade_cols = await _columns(conn, "trades")
        if "user_id" not in trade_cols:
            await _rebuild(conn, "trades", _TRADES_DDL,
                           _LEGACY_TRADE_COLS, owner_id)

        stat_cols = await _columns(conn, "statistics")
        if "user_id" not in stat_cols:
            await conn.execute(
                "ALTER TABLE statistics ADD COLUMN user_id INTEGER NOT NULL DEFAULT 0"
            )
            logger.info("Migrated table 'statistics' to per-user layout.")

        await conn.commit()

    logger.info("Database initialized at %s", _DB_PATH)


class Database:
    """Async database operations wrapper — every call is user scoped."""

    # ── Session state ───────────────────────────────────────────────────

    async def upsert_session_state(self, data: dict) -> None:
        async with aiosqlite.connect(_DB_PATH) as conn:
            await conn.execute("""
                INSERT INTO session_state (
                    user_id, bot_state, current_step, total_trades, total_wins,
                    total_losses, total_profit, current_balance, target_profit,
                    starting_balance, target_balance, last_traded_period,
                    last_order_id, step_amounts, step_count, updated_at
                ) VALUES (:user_id, :bot_state, :current_step, :total_trades,
                    :total_wins, :total_losses, :total_profit, :current_balance,
                    :target_profit, :starting_balance, :target_balance,
                    :last_traded_period, :last_order_id, :step_amounts,
                    :step_count, CURRENT_TIMESTAMP)
                ON CONFLICT(user_id) DO UPDATE SET
                    bot_state = excluded.bot_state,
                    current_step = excluded.current_step,
                    total_trades = excluded.total_trades,
                    total_wins = excluded.total_wins,
                    total_losses = excluded.total_losses,
                    total_profit = excluded.total_profit,
                    current_balance = excluded.current_balance,
                    target_profit = excluded.target_profit,
                    starting_balance = excluded.starting_balance,
                    target_balance = excluded.target_balance,
                    last_traded_period = excluded.last_traded_period,
                    last_order_id = excluded.last_order_id,
                    step_amounts = excluded.step_amounts,
                    step_count = excluded.step_count,
                    updated_at = CURRENT_TIMESTAMP
            """, data)
            await conn.commit()

    async def get_session_state(self, user_id: int) -> dict | None:
        async with aiosqlite.connect(_DB_PATH) as conn:
            conn.row_factory = aiosqlite.Row
            async with conn.execute(
                "SELECT * FROM session_state WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                return dict(row) if row else None

    # ── Trades ──────────────────────────────────────────────────────────

    async def insert_trade(self, trade: dict) -> None:
        async with aiosqlite.connect(_DB_PATH) as conn:
            await conn.execute("""
                INSERT OR IGNORE INTO trades
                (user_id, period_id, order_id, step, amount, trade_type,
                 status, created_at)
                VALUES (:user_id, :period_id, :order_id, :step, :amount,
                        :trade_type, :status, CURRENT_TIMESTAMP)
            """, trade)
            await conn.commit()

    async def update_trade_result(
        self,
        user_id: int,
        period_id: str,
        result: str,
        profit: float,
        order_id: str = "",
    ) -> None:
        async with aiosqlite.connect(_DB_PATH) as conn:
            await conn.execute("""
                UPDATE trades SET status = 'DONE', result = ?, profit = ?,
                    order_id = COALESCE(NULLIF(?, ''), order_id),
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = ? AND period_id = ?
            """, (result, profit, order_id, user_id, period_id))
            await conn.commit()

    async def period_already_traded(self, user_id: int, period_id: str) -> bool:
        async with aiosqlite.connect(_DB_PATH) as conn:
            async with conn.execute(
                "SELECT COUNT(*) FROM trades WHERE user_id = ? AND period_id = ?",
                (user_id, period_id),
            ) as cursor:
                row = await cursor.fetchone()
                return row[0] > 0

    async def get_pending_trade(self, user_id: int) -> dict | None:
        async with aiosqlite.connect(_DB_PATH) as conn:
            conn.row_factory = aiosqlite.Row
            async with conn.execute(
                "SELECT * FROM trades WHERE user_id = ? AND status = 'PENDING' "
                "ORDER BY created_at DESC LIMIT 1",
                (user_id,),
            ) as cursor:
                row = await cursor.fetchone()
                return dict(row) if row else None

    async def save_session_statistics(self, data: dict) -> None:
        async with aiosqlite.connect(_DB_PATH) as conn:
            await conn.execute("""
                INSERT INTO statistics
                (user_id, session_date, starting_balance, ending_balance,
                 target_profit, total_trades, total_wins, total_losses,
                 total_profit, outcome)
                VALUES (:user_id, :session_date, :starting_balance,
                        :ending_balance, :target_profit, :total_trades,
                        :total_wins, :total_losses, :total_profit, :outcome)
            """, data)
            await conn.commit()

    # ── Access control (owner grants / revokes) ─────────────────────────

    async def add_access(self, user_id: int, added_by: int) -> None:
        async with aiosqlite.connect(_DB_PATH) as conn:
            await conn.execute(
                "INSERT OR REPLACE INTO access_list (user_id, added_by) "
                "VALUES (?, ?)",
                (user_id, added_by),
            )
            await conn.commit()

    async def remove_access(self, user_id: int) -> bool:
        async with aiosqlite.connect(_DB_PATH) as conn:
            cursor = await conn.execute(
                "DELETE FROM access_list WHERE user_id = ?", (user_id,)
            )
            await conn.commit()
            return cursor.rowcount > 0

    async def has_access(self, user_id: int) -> bool:
        async with aiosqlite.connect(_DB_PATH) as conn:
            async with conn.execute(
                "SELECT 1 FROM access_list WHERE user_id = ?", (user_id,)
            ) as cursor:
                return await cursor.fetchone() is not None

    async def list_access(self) -> list[int]:
        async with aiosqlite.connect(_DB_PATH) as conn:
            async with conn.execute(
                "SELECT user_id FROM access_list ORDER BY added_at"
            ) as cursor:
                rows = await cursor.fetchall()
                return [int(r[0]) for r in rows]

    async def count_access(self) -> int:
        async with aiosqlite.connect(_DB_PATH) as conn:
            async with conn.execute(
                "SELECT COUNT(*) FROM access_list"
            ) as cursor:
                row = await cursor.fetchone()
                return int(row[0])


db = Database()
