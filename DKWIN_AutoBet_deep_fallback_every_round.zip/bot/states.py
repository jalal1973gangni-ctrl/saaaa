"""
Bot states for the FSM (Finite State Machine).
Each state represents a distinct phase of the owner conversation.
"""

from enum import Enum


class BotState(str, Enum):
    NOT_LOGGED_IN    = "NOT_LOGGED_IN"
    LOGIN_NUMBER     = "LOGIN_NUMBER"
    LOGIN_PASSWORD   = "LOGIN_PASSWORD"
    LOGGED_IN        = "LOGGED_IN"
    TARGET_INPUT     = "TARGET_INPUT"
    STEP_COUNT_INPUT = "STEP_COUNT_INPUT"
    STEP_AMOUNT_INPUT= "STEP_AMOUNT_INPUT"
    READY            = "READY"
    TRADING          = "TRADING"
    WAITING_RESULT   = "WAITING_RESULT"
    TARGET_REACHED   = "TARGET_REACHED"
    MAX_STEP_REACHED = "MAX_STEP_REACHED"
    LOGGING_OUT      = "LOGGING_OUT"
    ERROR            = "ERROR"
