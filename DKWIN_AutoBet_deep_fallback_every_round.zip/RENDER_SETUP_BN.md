# GitHub দিয়ে Render-এ চালানো

## ১. আগে টোকেন বদলান
আগের ZIP-এ Bot Token লেখা ছিল। Telegram-এর আসল BotFather থেকে পুরোনো token revoke
করে নতুন token নিন। পুরোনো ZIP বা token GitHub-এ দেবেন না। এই ZIP-এ token নেই।

## ২. GitHub-এ নতুন repo
ZIP extract করুন। GitHub-এ একটি নতুন private repository বানান। Extract করা ফোল্ডারের
**ভেতরের ফাইলগুলো** upload করুন, যাতে `main.py`, `requirements.txt`, `Dockerfile`,
`render.yaml` সরাসরি repo-এর প্রথম পাতায় থাকে। `.env`, database, logs upload করবেন না।
GitHub-এর সাধারণ upload-এ hidden files বাদ পড়তে পারে; `.gitignore`, `.dockerignore`
ও `.env.example` আছে কিনা দেখে নিন। `.env.example`-এ আসল token বসাবেন না।

## ৩. Render Blueprint
Render-এ login → **New → Blueprint** → GitHub repository connect করুন।
`render.yaml` থেকে Background Worker এবং 1 GB persistent disk তৈরি হবে।
Render যে গোপন মান চাইবে সেখানে দিন:
- `BOT_TOKEN`: নতুন BotFather token
- `OWNER_ID`: আপনার numeric Telegram ID

**Background Worker ও persistent disk paid; Deploy চাপার আগে বর্তমান খরচ দেখুন।**
এটি free Web Service নয়; ping দিয়ে free hosting করার ব্যবস্থা নেই।

Blueprint না ব্যবহার করলে **New → Background Worker**, Docker runtime বাছুন;
একই environment values দিন, disk `/app/storage`-এ mount করুন এবং
`DATABASE_PATH=/app/storage/bot_data.db` দিন। Docker নিজে `python main.py` চালায়।

## ৪. পরীক্ষা
Logs-এ `Bot is running` দেখুন। একই token-এর PC/VPS বট আগে বন্ধ করুন।
Telegram-এ `/start` → HGNICE → আগের মতো নিজের account দিয়ে login করুন।
ABOUT-এ আগের Developer Info থাকবে। আগে ছোট অঙ্কে পরীক্ষা করুন;
ভুল বা দুর্বল signal হলে `SIT OUT — NO BET` আসা স্বাভাবিক।

## ৫. Update ও restart
GitHub-এ code update করলে configured branch থেকে Render deploy হবে। একটাই instance রাখুন।
Restart/redeploy হলে account login memory থেকে মুছে যায়; আবার login ও target start করতে হবে।
Disk না থাকলে access list, statistics ও trade history হারাতে পারে। SQLite-এর safe backup রাখুন;
live `.db` ফাইল একা copy করলে WAL-এর নতুন data বাদ যেতে পারে।

## ১৭ ধাপ কী দেখে
Zigzag, zigzag break, short/long tan, long-run break candidate, BIG/SMALL trend,
2-2, 3-3, 2-1, 1-2, mirror, Markov, 4-4, repeated sequence,
momentum ও change point — সব ১৭টি detector প্রতিবার পরীক্ষা হয়, তবে সব vote দেয় না।
শেষ ১০টি ফল signal দেয়, বড় history দিয়ে পুরোনো ফলের পরীক্ষা হয়।
একই দিকে বেশি detector মানেই guaranteed win নয়। Score হলো evidence, জেতার probability নয়।
সব pattern বা trap ধরা এবং ২ level-এ win নিশ্চিত করা সম্ভব নয়। Historical L2 দেখালে
সেটি আগের complete engine replay-এর ফল; ভবিষ্যতের নিশ্চয়তা নয়।

এই package-এর tests synthetic/mocked; বাস্তব Telegram, HGNICE ও Render deploy যাচাই বাকি।
