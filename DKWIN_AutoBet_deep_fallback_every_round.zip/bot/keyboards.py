"""
Telegram keyboard layouts — premium redesign.
• BALANCE & STATISTICS buttons removed
• Cleaner, more focused main menu
"""

from telegram import (
    InlineKeyboardButton as _IKB,
    KeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)


# ── Coloured buttons (Telegram Bot API 9.4 "style": primary/success/danger)

def InlineKeyboardButton(text, style: str | None = None, **kw):
    return _IKB(text, api_kwargs={"style": style} if style else None, **kw)


def _btn(text: str, style: str | None = None) -> KeyboardButton:
    return KeyboardButton(text, api_kwargs={"style": style} if style else None)


# ── Home screen: HGNICE + ABOUT ─────────────────────────────────────────────

def home_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🎰  HGNICE", style="success", callback_data="action:hgnice"),
            InlineKeyboardButton("🎰  DKWIN", style="primary", callback_data="action:dkwin"),
        ],
        [InlineKeyboardButton("ℹ️  ABOUT", style="primary", callback_data="action:about")],
    ])


def about_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("📩  CONTACT", style="primary", url="https://t.me/TRADER_SAIF"),
        InlineKeyboardButton("⬅️  BACK", style="danger", callback_data="action:home"),
    ]])


# ── Welcome / Login screen ──────────────────────────────────────────────────

def login_keyboard(platform: str = "hgnice") -> InlineKeyboardMarkup:
    platform = platform if platform in {"hgnice", "dkwin"} else "hgnice"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🔐  LOGIN TO {platform.upper()}", style="success", callback_data=f"action:login:{platform}")]
    ])


# ── Main menu (reply keyboard) ───────────────────────────────────────────────

def main_menu_keyboard() -> ReplyKeyboardMarkup:
    """
    Main menu — BALANCE & STATISTICS removed.
    Only essential actions remain.
    """
    return ReplyKeyboardMarkup(
        [
            [_btn("🚀 START YOUR TARGET", "success")],
            [_btn("🛑 STOP TRADE", "danger"), _btn("🚪 LOGOUT", "primary")],
        ],
        resize_keyboard=True,
        one_time_keyboard=False,
    )


# ── Confirm dialogs ──────────────────────────────────────────────────────────

def confirm_keyboard(action: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅  YES, CONFIRM", style="success", callback_data=f"confirm:{action}:yes"),
            InlineKeyboardButton("❌  NO, CANCEL", style="danger", callback_data=f"confirm:{action}:no"),
        ]
    ])


# ── Trade setup: START / CANCEL ──────────────────────────────────────────────

def start_cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🚀  START TRADE", style="success", callback_data="action:start_trade"),
            InlineKeyboardButton("❌  CANCEL", style="danger", callback_data="action:cancel_trade"),
        ]
    ])


# ── Back to login ────────────────────────────────────────────────────────────

def back_to_login_keyboard(platform: str = "hgnice") -> InlineKeyboardMarkup:
    platform = platform if platform in {"hgnice", "dkwin"} else "hgnice"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🔐  LOGIN TO {platform.upper()}", style="success", callback_data=f"action:login:{platform}")]
    ])


# ── Remove keyboard ──────────────────────────────────────────────────────────

def remove_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()
