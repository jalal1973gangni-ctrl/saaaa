"""
Trade manager — orchestrates the full trade lifecycle.

ANALYSIS ENGINE (5-second budget, see core/analyzer.py):
  17 pattern detectors with latest-10 signals and past-only calibration
  every layer is walk-forward back-tested on the same history so its
  weight follows its real hit-rate; every valid fresh round receives a side.

The whole loop runs once per user: TradeManager(uid) owns its own
StateManager and HGNiceAPIClient, so several users can trade at once.
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Callable, Coroutine, Optional, Any

from bot.states import BotState
from config.settings import settings
from core.analyzer import analyse_market, next_period
from core.period_manager import period_manager
from core.risk_manager import risk_manager
from core.state_manager import StateManager, state_for
from services.hgnice_api import HGNiceAPIClient, HGNiceAPIError, client_for
from services.result_checker import result_checker
from services.wingo_api import wingo_api
from storage.database import db

logger = logging.getLogger(__name__)

BANNER  = "━━━━━━━━━━━━━━━━━━━━━━━━━━"
BANNER2 = "▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰"

NotifyFn = Callable[[str], Coroutine[Any, Any, None]]
AnimStartFn = Callable[[str], Coroutine[Any, Any, Any]]
AnimEditFn = Callable[[Any, str], Coroutine[Any, Any, None]]

# "Generating prediction" animation — 8 frames, PREDICTION_ANIM_SECONDS total
THINK_STAGES = (
    "Loading recent draws…",
    "Running 17 analysis layers…",
    "Back-testing layer hit-rates…",
    "Weighting consensus vote…",
    "Scoring prediction confidence…",
    "Verifying wallet & period…",
    "Composing prediction…",
    "Ready — placing auto bet…",
)
_SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


def should_sit_out(meta: dict, current_period: str) -> bool:
    """Never bet on errors/stale history, even when score gate is disabled."""
    latest = meta.get("latest_period")
    if not latest or meta.get("skip"):
        return True
    try:
        if next_period(latest) != current_period:
            return True
    except (TypeError, ValueError):
        return True
    # Do not suppress valid predictions just because the heuristic score is low.
    # Errors and stale/mismatched periods above still safely stop the round.
    return False


class _Animation:
    """A running 'generating prediction' Telegram message."""

    __slots__ = ("msg", "task")

    def __init__(self, msg: Any, task: asyncio.Task) -> None:
        self.msg = msg
        self.task = task


# ════════════════════════════════════════════════════════════════════════════
#  Helpers
# ════════════════════════════════════════════════════════════════════════════

def _bar(pct: int, width: int = 10) -> str:
    """Simple confidence bar: ████████░░ 80%"""
    filled = max(0, min(width, round(width * pct / 100)))
    return "█" * filled + "░" * (width - filled)


def _side_emoji(side: str) -> str:
    return "🔴" if side == "BIG" else "🔵"


# ════════════════════════════════════════════════════════════════════════════
#  TradeManager
# ════════════════════════════════════════════════════════════════════════════

class TradeManager:
    """Orchestrates the trading engine loop."""

    ANALYSIS_TIMEOUT = 5.0   # seconds

    def __init__(self, uid: int = 0) -> None:
        self._uid:         int                   = uid
        self._sm:          StateManager          = state_for(uid)
        self._api:         HGNiceAPIClient       = client_for(uid)
        self._task:        Optional[asyncio.Task] = None
        self._trade_lock   = asyncio.Lock()
        self._stop_event   = asyncio.Event()
        self._notify:      Optional[NotifyFn]    = None
        self._anim_start:  Optional[AnimStartFn] = None
        self._anim_edit:   Optional[AnimEditFn]  = None
        self._trade_type:  str                   = "AUTO"

    def set_notify(self, fn: NotifyFn) -> None:
        self._notify = fn

    def set_animator(self, start_fn: AnimStartFn, edit_fn: AnimEditFn) -> None:
        """Hook up the 'generating prediction' animation."""
        self._anim_start = start_fn
        self._anim_edit = edit_fn

    def set_trade_type(self, trade_type: str) -> None:
        self._trade_type = trade_type.upper()

    async def start(self, trade_type: str = "AUTO") -> None:
        if self._task and not self._task.done():
            logger.warning("Trading loop already running.")
            return
        self._stop_event.clear()
        self._trade_type = trade_type.upper()
        self._task = asyncio.create_task(self._trading_loop(), name="trading_loop")
        logger.info(
            "[user %s] Trading loop started — trade_type=%s",
            self._uid, self._trade_type,
        )

    async def stop(self, reason: str = "Manual stop") -> None:
        logger.info("[user %s] Stopping trading loop: %s", self._uid, reason)
        self._stop_event.set()
        if self._task and not self._task.done():
            try:
                await asyncio.wait_for(asyncio.shield(self._task), timeout=35)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._task.cancel()

    # ── Notification helper ───────────────────────────────────────────────

    async def _send(self, message: str) -> None:
        if self._notify:
            try:
                await self._notify(message)
            except Exception as exc:
                logger.error("Telegram notify failed: %s", exc)

    # ── Prediction animation ──────────────────────────────────────────────

    @staticmethod
    def _anim_frame(index: int, total: int) -> str:
        pct = round((index + 1) / total * 100)
        filled = round((index + 1) / total * 10)
        bar = "█" * filled + "░" * (10 - filled)
        return (
            f"{BANNER}\n"
            f"🧠 *GENERATING PREDICTION*\n"
            f"{BANNER}\n\n"
            f"{_SPIN[index % len(_SPIN)]} _{THINK_STAGES[index % len(THINK_STAGES)]}_\n\n"
            f"`[{bar}] {pct}%`\n\n"
            f"{BANNER}\n"
            f"⏳ _Running 17 layers + backtest…_"
        )

    async def _anim_run(self, msg: Any, frames: list[str], interval: float) -> None:
        for i in range(1, len(frames)):
            await asyncio.sleep(interval)
            try:
                await self._anim_edit(msg, frames[i])
            except Exception:
                return

    async def _start_animation(self) -> Optional[_Animation]:
        """Send the first animation frame and keep it spinning in background."""
        if not (self._anim_start and self._anim_edit):
            return None
        total = len(THINK_STAGES)
        frames = [self._anim_frame(i, total) for i in range(total)]
        interval = max(0.35, settings.PREDICTION_ANIM_SECONDS / total)
        try:
            msg = await self._anim_start(frames[0])
        except Exception as exc:
            logger.warning("Prediction animation start failed: %s", exc)
            return None
        if msg is None:
            return None
        return _Animation(msg, asyncio.create_task(self._anim_run(msg, frames, interval)))

    async def _anim_close(self, anim: Optional[_Animation], text: Optional[str] = None) -> None:
        """
        Finish the animation.

        ``text`` given  → let the frames run out, then edit the message into
                          the final text (the analysis + trade report).
        ``text`` is None → cancel the frames and delete the message.
        """
        if anim is None:
            return
        if text is None:
            anim.task.cancel()
            # gather(return_exceptions=True) swallows the child's
            # CancelledError but still propagates *our* cancellation.
            await asyncio.gather(anim.task, return_exceptions=True)
            try:
                await anim.msg.delete()
            except Exception:
                pass
            return
        try:
            await asyncio.wait_for(
                anim.task, settings.PREDICTION_ANIM_SECONDS + 5
            )
        except asyncio.CancelledError:
            anim.task.cancel()
            raise
        except asyncio.TimeoutError:
            anim.task.cancel()
        except Exception:
            pass
        try:
            await self._anim_edit(anim.msg, text)
        except Exception as exc:
            logger.debug("Animation final edit failed: %s", exc)

    # ── Main loop ─────────────────────────────────────────────────────────

    async def _trading_loop(self) -> None:
        logger.info("[user %s] Trading loop entered.", self._uid)
        # Local aliases so the body below stays readable.
        state_manager = self._sm
        hgnice_api    = self._api
        last_period: Optional[str] = state_manager.last_traded_period

        while not self._stop_event.is_set():
            try:
                anim = None
                now            = datetime.now(timezone.utc)
                current_period = period_manager.calculate_period(now)
                timer          = 30 - (now.second % 30)

                # Skip if already traded this period
                if current_period == last_period:
                    await asyncio.sleep(1)
                    continue

                # Skip if DB already has a trade for this period (restart recovery)
                if await db.period_already_traded(self._uid, current_period):
                    logger.info("Period %s already in DB. Skipping.", current_period)
                    last_period = current_period
                    state_manager.last_traded_period = current_period
                    await asyncio.sleep(1)
                    continue

                # WinGo 30S locks bets ~5s before period end
                if timer <= 6:
                    logger.info(
                        "Only %ds left in period %s — waiting for next period.",
                        timer, current_period,
                    )
                    await asyncio.sleep(timer + 1)
                    continue

                # Validate against API authoritative period
                api_latest = await wingo_api.get_latest_period()
                if api_latest and not period_manager.validate_against_api(
                    current_period, api_latest
                ):
                    await asyncio.sleep(1)
                    continue

                # Fetch balance (fall back to last known if API answers empty)
                try:
                    current_balance = await hgnice_api.get_balance(
                        fallback=state_manager.stats.current_balance
                    )
                    state_manager.stats.current_balance = current_balance
                except HGNiceAPIError as exc:
                    logger.error("Balance fetch failed: %s", exc)
                    await self._send(
                        f"{BANNER}\n"
                        f"🛑 *AUTO TRADE STOPPED*\n"
                        f"{BANNER}\n\n"
                        f"❌ Balance fetch failed\n`{exc}`"
                    )
                    await state_manager.set_state(BotState.ERROR)
                    break

                # Check target
                if risk_manager.is_target_reached(
                    current_balance, state_manager.config.target_balance
                ):
                    await self._handle_target_reached(current_balance)
                    break

                # ── RUN ANALYSIS (≤ 5 seconds) ─────────────────────────────
                # The "generating prediction" animation runs in the background
                # *while* the analysis runs, so it never delays the bet.
                anim = None
                if self._trade_type == "AUTO":
                    anim = await self._start_animation()
                    try:
                        trade_side, meta = await asyncio.wait_for(
                            analyse_market(),
                            timeout=self.ANALYSIS_TIMEOUT,
                        )
                    except asyncio.TimeoutError:
                        logger.warning("Analysis timed out — sitting out.")
                        trade_side = "SMALL"
                        meta = {
                            "confidence": 0,
                            "skip": True,
                            "elapsed_ms": 5000,
                            "structure": "TIMEOUT",
                            "report": "⏱️ Analysis timeout — no bet",
                            "detail": "analysis budget exceeded",
                        }
                else:
                    trade_side = self._trade_type
                    meta = {"confidence": 99, "elapsed_ms": 0, "report": "Manual override"}

                # ── Confidence gate ────────────────────────────────────────
                # Valid fresh rounds are always predicted; only API/analysis errors
                # or stale/mismatched periods are blocked by should_sit_out().
                min_conf = settings.MIN_CONFIDENCE
                if self._trade_type == "AUTO":
                    conf_now = int(meta.get("confidence", 0))
                    if should_sit_out(meta, current_period):
                        last_period = current_period
                        state_manager.last_traded_period = current_period
                        logger.info(
                            "Sit-out: period %s confidence %d%% < %d%%.",
                            current_period, conf_now, min_conf,
                        )
                        await self._anim_close(anim, (
                            f"{BANNER}\n"
                            f"🛑 *SIT OUT — NO BET*\n"
                            f"{BANNER}\n\n"
                            f"⏱️ *Period*   : `{current_period}`\n"
                            f"🎯 *Evidence score*: *{conf_now}%*\n\n"
                            f"{meta.get('report', '')}\n\n"
                            f"{BANNER}\n"
                            f"_History/API error or period mismatch — prediction withheld to avoid using stale data._"
                        ))
                        continue

                # ── Get step ───────────────────────────────────────────────
                current_step = state_manager.current_step
                step_idx     = current_step - 1

                # Auto-rebuild steps for every +100 balance (only at step 1)
                if current_step == 1:
                    from core.risk_manager import build_steps, STEP_REBUILD_EVERY
                    cfg = state_manager.config
                    if cfg.step_base_balance <= 0:
                        cfg.step_base_balance = current_balance
                    if current_balance >= cfg.step_base_balance + STEP_REBUILD_EVERY:
                        new_steps = build_steps(current_balance, cfg.step_count)
                        if new_steps:
                            cfg.step_amounts = new_steps
                            cfg.step_base_balance = current_balance
                            logger.info("Steps rebuilt for balance %.2f: %s",
                                        current_balance, new_steps)

                if step_idx >= len(state_manager.config.step_amounts):
                    await self._anim_close(anim)
                    await self._handle_max_step_exhausted()
                    break

                amount = state_manager.config.step_amounts[step_idx]

                # ── Top up the GAME wallet before it is checked/bet ─────────
                # hgnice9.com sweeps the game wallet back into the platform
                # wallet (webapi/RecoverSaasBalance) as soon as the WinGo page
                # is closed — and webapi/Transfer is what fills it again.
                # So whenever the game wallet cannot cover the next stake we
                # move the money over ourselves instead of betting on ৳0.00.
                if current_balance < amount:
                    logger.warning(
                        "Game wallet short: balance=%.2f < stake=%.2f "
                        "— transferring platform → game wallet.",
                        current_balance, amount,
                    )
                    await hgnice_api.transfer_to_game()
                    try:
                        current_balance = await hgnice_api.get_balance(
                            fallback=state_manager.stats.current_balance
                        )
                        state_manager.stats.current_balance = current_balance
                        logger.info("Balance after transfer: %.2f", current_balance)
                    except HGNiceAPIError as exc:
                        logger.warning("Balance re-fetch after transfer failed: %s", exc)

                can_trade, reason = risk_manager.can_trade(
                    current_balance, amount, current_step, state_manager.config.step_count
                )
                if not can_trade:
                    await self._anim_close(anim)
                    await self._send(
                        f"{BANNER}\n"
                        f"🛑 *TRADE BLOCKED*\n"
                        f"{BANNER}\n\n"
                        f"❌ {reason}"
                    )
                    await state_manager.set_state(BotState.ERROR)
                    break

                # ── Place trade ────────────────────────────────────────────
                async with self._trade_lock:
                    if self._stop_event.is_set():
                        await self._anim_close(anim)
                        break

                    # Re-check timer right before placing
                    now   = datetime.now(timezone.utc)
                    timer = 30 - (now.second % 30)
                    if timer <= 5:
                        logger.info("Timer=%ds — too late to bet, skipping.", timer)
                        await self._anim_close(anim)
                        await asyncio.sleep(timer + 1)
                        continue

                    # Save PENDING to DB
                    await db.insert_trade({
                        "user_id":    self._uid,
                        "period_id":  current_period,
                        "order_id":   "",
                        "step":       current_step,
                        "amount":     amount,
                        "trade_type": trade_side,
                        "status":     "PENDING",
                    })

                    # Place via HGNICE API
                    order_id = ""
                    trade_response = None
                    last_exc: Optional[HGNiceAPIError] = None
                    # One automatic recovery attempt: if the server says the
                    # wallet is short, move the platform money into the game
                    # wallet and immediately re-place the very same bet.
                    for attempt in (1, 2):
                        try:
                            trade_response = await hgnice_api.place_trade(
                                current_period, trade_side, amount
                            )
                            last_exc = None
                            break
                        except HGNiceAPIError as exc:
                            last_exc = exc
                            if (
                                attempt == 1
                                and "balance" in str(exc).lower()
                                and "not enough" in str(exc).lower()
                            ):
                                logger.warning(
                                    "Bet rejected (%s) — auto top-up "
                                    "(platform → game) and retrying once.",
                                    exc,
                                )
                                await hgnice_api.transfer_to_game()
                                await asyncio.sleep(1.0)
                                continue
                            break

                    exc = last_exc
                    if last_exc is None:
                        order_id = str(trade_response.get("orderId", ""))
                        state_manager.last_order_id = order_id
                        logger.info(
                            "Trade submitted: period=%s order=%s amount=%.2f side=%s",
                            current_period, order_id, amount, trade_side,
                        )
                        print(f">>> BET PLACED ✅  period={current_period} side={trade_side} amount={amount} order={order_id}", flush=True)
                    else:
                        logger.error("Trade placement failed: %s", exc)
                        print(f">>> BET FAILED ❌  period={current_period} side={trade_side} amount={amount} reason={exc}", flush=True)
                        # One-line diagnosis: is it really a money problem?
                        try:
                            ov = await hgnice_api.get_wallet_overview()
                            logger.error(
                                "Bet rejected (%s) — game(GetBalance)=%s | platform=%s "
                                "| arGame=%s | lottery=%s",
                                exc, current_balance,
                                ov["platform"], ov["arGame"], ov["lottery"],
                            )
                        except Exception as diag_exc:
                            logger.warning("Wallet diagnosis failed: %s", diag_exc)
                        await db.update_trade_result(
                            self._uid, current_period, "ERROR", 0.0, ""
                        )

                        if "settled" in str(exc).lower():
                            logger.warning("Period %s already settled.", current_period)
                            last_period = current_period
                            state_manager.last_traded_period = current_period
                            now_after = datetime.now(timezone.utc)
                            wait_s = max(1, 31 - (now_after.second % 30))
                            await self._anim_close(anim)
                            await asyncio.sleep(wait_s)
                            continue

                        await self._anim_close(anim)
                        await self._send(
                            f"{BANNER}\n"
                            f"🛑 *TRADE FAILED*\n"
                            f"{BANNER}\n\n"
                            f"❌ `{exc}`"
                        )
                        await state_manager.set_state(BotState.ERROR)
                        break

                    # ── Build & send analysis + trade notification ──────────
                    conf      = meta.get("confidence", 50)
                    bar       = _bar(conf)
                    elapsed   = meta.get("elapsed_ms", 0)
                    report    = meta.get("report", "")
                    detail    = meta.get("detail", "")
                    structure = meta.get("structure", "")
                    side_icon = _side_emoji(trade_side)

                    text = (
                        f"{BANNER}\n"
                        f"🤖 *NEW TRADE PLACED*\n"
                        f"{BANNER}\n\n"
                        f"⏱️ *Period*  : `{current_period}`\n"
                        f"🕐 *Timer*   : `{timer}s remaining`\n"
                        f"📊 *Market*  : `{structure}`\n\n"
                        f"╔═══════════════════════╗\n"
                        f"║   🧠 ANALYSIS REPORT   ║\n"
                        f"╚═══════════════════════╝\n"
                        f"{report}\n\n"
                        f"{BANNER}\n"
                        f"📊 *Evidence score* : [{bar}] *{conf}%*\n"
                        f"🎯 *Consensus*  : _{detail}_\n"
                        f"⚡ *Analyzed in*: `{elapsed}ms`\n\n"
                        f"{BANNER}\n"
                        f"{side_icon} *PREDICTION* : *{trade_side}*\n"
                        f"🚀 *Step*      : *{current_step}*\n"
                        f"💵 *Amount*    : *৳ {amount:.2f}*\n"
                        f"💰 *Balance*   : `৳ {current_balance:.2f}`\n"
                        f"{BANNER}\n"
                        f"⏳ _Waiting for result…_"
                    )

                    if anim is not None:
                        # The animation message *becomes* the trade report.
                        await self._anim_close(anim, text)
                    else:
                        await self._send(text)

                    state_manager.last_traded_period = current_period
                    last_period = current_period
                    await state_manager.set_state(BotState.WAITING_RESULT)

                # ── Wait for result ────────────────────────────────────────
                outcome, profit = await result_checker.wait_for_result(
                    current_period, trade_side, amount, api=self._api
                )

                await db.update_trade_result(
                    self._uid, current_period, outcome, profit, order_id
                )

                # Update stats
                state_manager.stats.total_trades += 1
                if outcome == "WIN":
                    state_manager.stats.total_wins   += 1
                    state_manager.stats.total_profit += profit
                    next_step = 1
                elif outcome == "LOSS":
                    state_manager.stats.total_losses += 1
                    state_manager.stats.total_profit += profit
                    next_step = current_step + 1
                else:
                    next_step = current_step

                # Fetch fresh balance (fall back to last known if API is empty)
                try:
                    updated_balance = await hgnice_api.get_balance(
                        fallback=state_manager.stats.current_balance
                    )
                    state_manager.stats.current_balance = updated_balance
                except HGNiceAPIError:
                    updated_balance = state_manager.stats.current_balance

                # Result notification
                if outcome == "WIN":
                    res_icon  = "🟢"
                    res_label = "WIN ✅"
                    p_text    = f"+৳ {profit:.2f}"
                elif outcome == "LOSS":
                    res_icon  = "🔴"
                    res_label = "LOSS ❌"
                    p_text    = f"-৳ {amount:.2f}"
                else:
                    res_icon  = "⚠️"
                    res_label = "ERROR ⚠️"
                    p_text    = "—"

                sm        = state_manager
                win_rate  = (
                    f"{sm.stats.total_wins / sm.stats.total_trades * 100:.1f}%"
                    if sm.stats.total_trades else "—"
                )

                await self._send(
                    f"{BANNER}\n"
                    f"{res_icon} *TRADE RESULT*\n"
                    f"{BANNER}\n\n"
                    f"⏱️ *Period*  : `{current_period}`\n"
                    f"{_side_emoji(trade_side)} *Side*    : *{trade_side}*\n"
                    f"🚀 *Step*    : *{current_step}*\n"
                    f"💵 *Amount*  : *৳ {amount:.2f}*\n\n"
                    f"📊 *Result*  : *{res_label}*\n"
                    f"💹 *P/L*     : *{p_text}*\n"
                    f"💰 *Balance* : `৳ {updated_balance:.2f}`\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏆 *Wins* : {sm.stats.total_wins}  "
                    f"🔴 *Losses* : {sm.stats.total_losses}  "
                    f"📈 *Rate* : {win_rate}\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"➡️ *Next Step* : *{next_step}*"
                )

                state_manager.current_step = next_step

                if next_step > state_manager.config.step_count:
                    await self._handle_max_step_exhausted()
                    break

                await state_manager.set_state(BotState.TRADING)
                await state_manager.persist_safe_state()

                if risk_manager.is_target_reached(
                    updated_balance, state_manager.config.target_balance
                ):
                    await self._handle_target_reached(updated_balance)
                    break

            except asyncio.CancelledError:
                logger.info("Trading loop cancelled.")
                try:
                    anim.task.cancel()
                except Exception:
                    pass
                break
            except Exception as exc:
                logger.exception("Unexpected error in trading loop: %s", exc)
                await self._anim_close(anim)
                await self._send(
                    f"{BANNER}\n"
                    f"🛑 *AUTO TRADE STOPPED*\n"
                    f"{BANNER}\n\n"
                    f"⚠️ Unexpected error:\n`{exc}`"
                )
                await state_manager.set_state(BotState.ERROR)
                break

        logger.info("Trading loop exited.")

    # ── Target reached ────────────────────────────────────────────────────

    async def _handle_target_reached(self, final_balance: float) -> None:
        state_manager = self._sm
        hgnice_api    = self._api
        sm = state_manager
        await sm.set_state(BotState.TARGET_REACHED)

        from datetime import date
        await db.save_session_statistics({
            "user_id":         self._uid,
            "session_date":     date.today().isoformat(),
            "starting_balance": sm.config.starting_balance,
            "ending_balance":   final_balance,
            "target_profit":    sm.config.target_profit,
            "total_trades":     sm.stats.total_trades,
            "total_wins":       sm.stats.total_wins,
            "total_losses":     sm.stats.total_losses,
            "total_profit":     sm.stats.total_profit,
            "outcome":          "TARGET_REACHED",
        })

        profit_made = final_balance - sm.config.starting_balance
        win_rate = (
            f"{sm.stats.total_wins / sm.stats.total_trades * 100:.1f}%"
            if sm.stats.total_trades else "—"
        )

        await self._send(
            f"{BANNER}\n"
            f"🎯 *TARGET REACHED* 🎉\n"
            f"{BANNER}\n\n"
            f"╔═══════════════════════╗\n"
            f"║   💎 SESSION SUMMARY   ║\n"
            f"╚═══════════════════════╝\n\n"
            f"💰 *Start Balance* : `৳ {sm.config.starting_balance:.2f}`\n"
            f"💳 *Final Balance* : `৳ {final_balance:.2f}`\n"
            f"💹 *Profit Made*   : `+৳ {profit_made:.2f}`\n\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 *Trades* : {sm.stats.total_trades}  "
            f"🟢 *Win* : {sm.stats.total_wins}  "
            f"🔴 *Loss* : {sm.stats.total_losses}\n"
            f"🏆 *Win Rate* : {win_rate}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"✅ *Account auto-logged out.*\n"
            f"_Type /start to begin a new session._"
        )

        logger.info("Target reached. Logging out.")
        await sm.set_state(BotState.LOGGING_OUT)
        try:
            await hgnice_api.logout()
        except Exception as exc:
            logger.error("Logout error after target: %s", exc)
        sm.reset()
        try:
            await self._send("👇 Type /start and press *LOGIN TO ACCOUNT* to begin again.")
        except Exception:
            pass

    # ── Max step exhausted ────────────────────────────────────────────────

    async def _handle_max_step_exhausted(self) -> None:
        state_manager = self._sm
        hgnice_api    = self._api
        sm = state_manager
        await sm.set_state(BotState.MAX_STEP_REACHED)

        try:
            final_balance = await hgnice_api.get_balance(
                fallback=sm.stats.current_balance
            )
            sm.stats.current_balance = final_balance
        except HGNiceAPIError:
            final_balance = sm.stats.current_balance

        await self._send(
            f"{BANNER}\n"
            f"⚠️ *ALL STEPS EXHAUSTED*\n"
            f"{BANNER}\n\n"
            f"Market conditions were unfavourable.\n\n"
            f"🔴 *Market kharap silo — target pura hoi naai.*\n"
            f"   _Poree abr try korben._\n\n"
            f"💰 *Balance* : `৳ {final_balance:.2f}`\n"
            f"📉 *Losses*  : *{sm.stats.total_losses}*\n\n"
            f"Auto trade *STOPPED*.\n"
            f"Use *🚀 START YOUR TARGET* to try again."
        )

        logger.info("Max step exhausted.")
        await sm.set_state(BotState.LOGGED_IN)


# ── Per-user registry ────────────────────────────────────────────────────────

_traders: dict[int, TradeManager] = {}


def trade_for(uid: int) -> TradeManager:
    """Return (creating on first use) the TradeManager owned by ``uid``."""
    tm = _traders.get(uid)
    if tm is None:
        tm = TradeManager(uid)
        _traders[uid] = tm
    return tm
