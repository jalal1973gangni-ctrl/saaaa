"""
Core state manager.
Holds the owner session, trading config, and FSM state in memory.
Only safe (non-credential) fields are persisted to the database.
"""

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Optional

from bot.states import BotState
from storage.database import db

logger = logging.getLogger(__name__)


@dataclass
class TradingConfig:
    target_profit: float = 0.0
    starting_balance: float = 0.0
    target_balance: float = 0.0
    step_count: int = 0
    step_amounts: list[float] = field(default_factory=list)
    step_base_balance: float = 0.0  # balance the current steps were built from
    current_step_input: int = 0  # which step we are currently collecting input for


@dataclass
class TradeStats:
    total_trades: int = 0
    total_wins: int = 0
    total_losses: int = 0
    total_profit: float = 0.0
    current_balance: float = 0.0


@dataclass
class SessionData:
    """In-memory session - never persisted to disk."""
    account_number: Optional[str] = None
    # credentials stored ONLY in memory, never logged/persisted
    _password: Optional[str] = None
    session_token: Optional[str] = None
    cookies: dict = field(default_factory=dict)
    headers: dict = field(default_factory=dict)
    account_masked: Optional[str] = None
    user_id: Optional[str] = None
    nick_name: Optional[str] = None

    def set_password(self, password: str) -> None:
        self._password = password

    def get_password(self) -> Optional[str]:
        return self._password

    def clear_credentials(self) -> None:
        self._password = None
        self.session_token = None
        self.cookies = {}
        self.headers = {}
        self.user_id = None
        self.nick_name = None


class StateManager:
    """Per-user state manager (FSM state, trading config, stats)."""

    def __init__(self, uid: int = 0) -> None:
        self.uid: int = uid
        self.state: BotState = BotState.NOT_LOGGED_IN
        self.session: SessionData = SessionData()
        self.config: TradingConfig = TradingConfig()
        self.stats: TradeStats = TradeStats()
        self.current_step: int = 1
        self.last_traded_period: Optional[str] = None
        self.last_order_id: Optional[str] = None
        self._lock = asyncio.Lock()

    async def set_state(self, new_state: BotState) -> None:
        async with self._lock:
            old_state = self.state
            self.state = new_state
            logger.info(
                "[user %s] State transition: %s → %s",
                self.uid, old_state.value, new_state.value,
            )

    def get_state(self) -> BotState:
        return self.state

    def reset(self) -> None:
        """Full reset after logout. Clears ALL credentials and trading state."""
        logger.info("[user %s] Resetting state manager to NOT_LOGGED_IN.", self.uid)
        self.session.clear_credentials()
        self.session.account_number = None
        self.session.account_masked = None
        self.config = TradingConfig()
        self.stats = TradeStats()
        self.current_step = 1
        self.last_traded_period = None
        self.last_order_id = None
        self.state = BotState.NOT_LOGGED_IN

    async def persist_safe_state(self) -> None:
        """Persist only non-sensitive trading state to database."""
        try:
            await db.upsert_session_state({
                "user_id": self.uid,
                "current_step": self.current_step,
                "total_trades": self.stats.total_trades,
                "total_wins": self.stats.total_wins,
                "total_losses": self.stats.total_losses,
                "total_profit": self.stats.total_profit,
                "current_balance": self.stats.current_balance,
                "target_profit": self.config.target_profit,
                "starting_balance": self.config.starting_balance,
                "target_balance": self.config.target_balance,
                "last_traded_period": self.last_traded_period or "",
                "last_order_id": self.last_order_id or "",
                "step_amounts": ",".join(str(a) for a in self.config.step_amounts),
                "step_count": self.config.step_count,
                "bot_state": self.state.value,
            })
        except Exception as exc:
            logger.error("Failed to persist state: %s", exc)


# ── Per-user registry ────────────────────────────────────────────────────────

_states: dict[int, StateManager] = {}


def state_for(uid: int) -> StateManager:
    """Return (creating on first use) the StateManager owned by ``uid``."""
    sm = _states.get(uid)
    if sm is None:
        sm = StateManager(uid)
        _states[uid] = sm
    return sm
